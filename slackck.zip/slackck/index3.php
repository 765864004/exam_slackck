<?php

if(version_compare(PHP_VERSION,'5.3.0','<'))  die('require PHP > 5.3.0 !');
//define('BIND_MODULE','Admin');


// 定义移动端模块
$mobile_agents = Array("240x320","acer","acoon","acs-","abacho","ahong","airness","alcatel","amoi","android","anywhereyougo.com",/* "applewebkit/525","applewebkit/532", */"asus","audio","au-mic","avantogo","becker","benq","bilbo","bird","blackberry","blazer","bleu","cdm-","compal","coolpad","danger","dbtel","dopod","elaine","eric","etouch","fly ","fly_","fly-","go.web","goodaccess","gradiente","grundig","haier","hedy","hitachi","htc","huawei","hutchison","inno","ipad","ipaq","ipod","jbrowser","kddi","kgt","kwc","lenovo","lg ","lg2","lg3","lg4","lg5","lg7","lg8","lg9","lg-","lge-","lge9","longcos","maemo","mercator","meridian","micromax","midp","mini","mitsu","mmm","mmp","mobi","mot-","moto","nec-","netfront","newgen","nexian","nf-browser","nintendo","nitro","nokia","nook","novarra","obigo","palm","panasonic","pantech","philips","phone","pg-","playstation","pocket","pt-","qc-","qtek","rover","sagem","sama","samu","sanyo","samsung","sch-","scooter","sec-","sendo","sgh-","sharp","siemens","sie-","softbank","sony","spice","sprint","spv","symbian","tablet","talkabout","tcl-","teleca","telit","tianyu","tim-","toshiba","tsm","up.browser","utec","utstar","verykool","virgin","vk-","voda","voxtel","vx","wap","wellco","wig browser","wii","windows ce","wireless","xda","xde","zte");
if (preg_match("/(".implode('|',$mobile_agents).")/i",strtolower($_SERVER['HTTP_USER_AGENT']))) {
	 echo '您是手机端访问的，已跳转到手机端';
    //移动端模块
    //define('BIND_MODULE','Mobile/Index/index');
     define('APP_NAME','Mobile');
     define('APP_PATH','./Mobile/');
}else{
    echo '你是PC端访问的';
	//define('BIND_MODULE','Home/Index/index');

  define('APP_NAME','Home');
  define('APP_PATH','./Home/');

}


define('APP_DEBUG',True);
define('APP_PATH','./Application/');
require './ThinkPHP/ThinkPHP.php';
