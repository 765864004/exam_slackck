//提示信息
$(function () {
	$("[data-toggle='tooltip']").tooltip();
});