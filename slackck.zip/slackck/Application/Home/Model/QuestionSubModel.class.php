<?php
namespace Home\Model;
use Think\Model\RelationModel;

 class QuestionSubModel extends RelationModel{
   protected $_link=array(
       'area_list' => array(
			'mapping_type'  => self::BELONGS_TO,
			'class_name'    => 'area_list',
			'foreign_key'   => 'question_sub_areaid',
			'as_fields'  => 'area_list_name',
		),
   		'question_details' => array(
   				'mapping_type'  => self::BELONGS_TO,
   				'class_name'    => 'question_details',
   				'foreign_key'   => 'question_sub_areaid',
   				'as_fields'  => 'question_details_time,question_details_dan,question_details_dannum,question_details_duo,question_details_duonum,question_details_pan,question_details_pannum,question_details_countnum,question_details_starttime,question_details_endtime',
   		),
   );

}




?>