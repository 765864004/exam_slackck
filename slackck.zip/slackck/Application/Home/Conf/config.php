<?php
return array (
'DEFAULT_THEME'=>'Default',
);

return array_merge(include './Conf/config.php', $config);


