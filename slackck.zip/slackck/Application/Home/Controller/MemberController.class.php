<?php
namespace Home\Controller;
use Think\Controller;
use LT\ThinkSDK\ThinkOauth;
use Event\TypeEvent;

class MemberController extends CommonController {

	public function member_list_edit(){
		$member_list_id=$_SESSION['member_list_id'];
		$member_list_all=M('member_list')->where(array('member_list_id'=>$member_list_id))->find();
		$this->assign('member_list_edit',$member_list_all);
		$this->display();
	}
	

	/*
	 * 修改用户操作
	 */
	public function member_list_runedit(){
		if (!IS_AJAX){
			$this->error('提交方式不正确',U('member_list_edit'),0);
		}else{
				
			$sl_data['member_list_id']=I('member_list_id');
			
			$pwd=I('member_list_pwd');
			if (!empty($pwd)){
				$sl_data['member_list_pwd']=I('member_list_pwd','','md5');
			}
			$sl_data['member_list_realname']=I('member_list_realname');
			$sl_data['member_list_tel']=I('member_list_tel');
			$sl_data['member_list_email']=I('member_list_email');

				
			M('member_list')->save($sl_data);
			$this->success('个人信息修改成功',U('member_list_edit'),1);
		}
	}
	
	
}