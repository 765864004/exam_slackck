<?php
namespace Admin\Controller;
use Think\Controller;
use Common\Controller\AuthController;
use Think\Auth;

class DepController extends AuthController {

	public function dep_list(){
		$area_list=M('area_list')->select();
		$this->assign('area_list',$area_list);
		
		if ($_SESSION['aid']!=1){
			$map['dep_list_areaid']=array('eq',$_SESSION['admin_areaid']);
		}
		
		$dep_list=D('Dep_list')->where($map)->order('dep_list_areaid')->relation(true)->select();
		$this->assign('dep_list',$dep_list);
		
		$auth_group=M('auth_group')->select();
		$this->assign('auth_group',$auth_group);
		
		$this->display();
	}
	
	public function dep_list_runadd(){
		if (!IS_AJAX){
			$this->error('提交方式不正确',0,0);
		}else{
			$dep_list=M('dep_list');
			if (!$dep_list->autoCheckToken($_POST)){
				$this->error('请勿重复提交,刷新后再操作',0,0);
			}else{
				$sl_data=array(
						'dep_list_areaid'=>I('dep_list_areaid'),
						'dep_list_name'=>I('dep_list_name'),
				);
				$dep_list->field('dep_list_areaid,dep_list_name')->add($sl_data);
				$this->success('单位添加成功，返回列表',U('dep_list'),1);
				
			}
		}
	}
	
	public function dep_list_runedit(){
		if (!IS_AJAX){
			$this->error('提交方式不正确',0,0);
		}else{
			$dep_list=M('dep_list');
			if (!$dep_list->autoCheckToken($_POST)){
				$this->error('请勿重复提交,刷新后再操作',0,0);
			}else{
				$sl_data=array(
						'dep_list_id'=>I('dep_list_id'),
						'dep_list_name'=>I('dep_list_name'),
				);
				$dep_list->field('dep_list_id,dep_list_name')->save($sl_data);
				$this->success('单位添加成功，返回列表',U('dep_list'),1);
	
			}
		}
	}
	
	public function dep_list_del(){
		$p=I('p');
		$dep_list_id=I('dep_list_id');
		$check_depid=M('dep_list')->where(array('dep_list_id'=>$dep_list_id))->find();
		if (empty($check_depid)){
			$this->error('参数不正确',0,0);
		}else {
			$check_authdel=M('dep_list')->where(array('dep_list_areaid'=>$_SESSION['admin_areaid'],'dep_list_id'=>$dep_list_id))->find();
			if (empty($check_authdel)){
				$this->error('该单位您没有权限删除',0,0);
			}else {
				M('dep_list')->where(array('dep_list_id'=>$dep_list_id))->delete();
				M('admin')->where(array('admin_depid'=>$dep_list_id))->delete();
				$this->redirect('dep_list', array('p' => $p));
			}
		}
	}
	
	public function dep_admin_del(){
		$p=I('p');
		$admin_id=I('admin_id');
		$check_admin=M('admin')->where(array('admin_id'=>$admin_id))->find();
		if (empty($check_admin)){
			$this->error('参数不正确',0,0);
		}else {
			if ($_SESSION['aid']!=1){
				$check_authdel=M('admin')->where(array('admin_areaid'=>$_SESSION['admin_areaid'],'admin_id'=>$admin_id))->find();
				if (empty($check_authdel)){
					$this->error('该单位管理员您没有权限删除',0,0);
				}else {
					M('admin')->where(array('admin_id'=>$admin_id))->delete();
					$this->redirect('dep_list', array('p' => $p));
				}
			}else{
				M('admin')->where(array('admin_id'=>$admin_id))->delete();
				$this->redirect('dep_list', array('p' => $p));
			}
		}
	}
	
	

	public function dep_list_runadmin(){
		if (!IS_AJAX){
			$this->error('提交方式不正确',0,0);
		}else{
			$admin=M('admin');
			if (!$admin->autoCheckToken($_POST)){
				$this->error('表单令牌错误,刷新页面尝试恢复',0,0);
			}else{
				$admin_access=M('auth_group_access');
				$check_user=$admin->where(array('admin_username'=>I('admin_username')))->find();
				if ($check_user){
					$this->error('用户已存在，请重新输入用户名',0,0);
				}
				$sldata=array(
						'admin_username'=>I('admin_username'),
						'admin_pwd'=>I('admin_pwd','','md5'),
						'admin_email'=>I('admin_email'),
						'admin_tel'=>I('admin_tel'),
						'admin_open'=>I('admin_open'),
						'admin_realname'=>I('admin_realname'),
						'admin_ip'=>get_client_ip(),
						'admin_addtime'=>time(),
						'admin_areaid'=>I('admin_areaid'),
						'admin_depid'=>I('admin_depid'),
				);
				$result=$admin->field('admin_username,admin_pwd,admin_email,admin_tel,admin_open,admin_realname,admin_ip,admin_addtime,admin_areaid,admin_depid')->add($sldata);
				$accdata=array(
						'uid'=>$result,
						'group_id'=>I('group_id'),
				);
				$admin_access->field('uid,group_id')->add($accdata);
				$this->success('管理员添加成功',U('dep_list'),1);
				
			}
		}
	}
		
	
}