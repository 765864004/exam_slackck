<?php
namespace Admin\Controller;
use Think\Controller;
use Common\Controller\AuthController;
use Think\Auth;
use Vendor\ThinkImage\ThinkImage;

class QustController extends AuthController {

	//单选题
	public function qust_danlist(){
		if ($_SESSION['aid']!=1){
			$map['question_sub_areaid']=array('eq',$_SESSION['admin_areaid']);
			$map_dan['question_list_areaid']=array('eq',$_SESSION['admin_areaid']);
		}
		$map['question_sub_zt']=array('eq',1);
		$question_sub=M('question_sub')->where($map)->select();
		$this->assign('question_sub',$question_sub);
		
		$question_list=D('Question_list');
		$val=I('val');
		$map_dan['question_list_var']= array('like',"%".$val."%");
		$map_dan['question_list_type']=array('eq',1);
		$count= $question_list->where($map_dan)->count();// 查询满足要求的总记录数
		$Page= new \Think\Page($count,C('DB_PAGENUM'));// 实例化分页类 传入总记录数和每页显示的记录数
		$show= $Page->show();// 分页显示输出
		
		$question_list=$question_list->limit($Page->firstRow.','.$Page->listRows)
			->where($map_dan)->relation(true)->order("question_list_id desc")->select();
		$this->assign('question_list',$question_list);
		$this->assign('page',$show);
		$this->assign('val',$val);
		$this->display();
	}

	//增加单选题
	public function question_dan_runadd(){
		if (!IS_AJAX){
			$this->error("提交方式错误！",U('qust_danlist'),0);
		}else{
			$question_list=M('question_list');
			if (!$question_list->autoCheckToken($_POST)){
				$this->error('表单令牌错误,刷新页面尝试恢复',U('qust_danlist'),0);
			}else{
				$sl_data=array(
						'question_list_subid'=>I('question_list_subid'),
						'question_list_type'=>1,
						'question_list_var'=>I('question_list_var'),
						'question_list_op1'=>I('question_list_op1'),
						'question_list_op2'=>I('question_list_op2'),
						'question_list_op3'=>I('question_list_op3'),
						'question_list_op4'=>I('question_list_op4'),
						'question_list_ans'=>I('question_list_ans'),
						'question_list_addtime'=>time(),
						'question_list_areaid'=>$_SESSION['admin_areaid'],
				);
				session('question_list_subid',I('question_list_subid'));
				$question_list->field('question_list_subid,question_list_type,question_list_var,question_list_op1,question_list_op2,question_list_op3,question_list_op4,question_list_ans,question_list_addtime,question_list_areaid')->add($sl_data);
				$this->success('考试题目保存成功',U('qust_danlist'),1);
			}
		}
	}

	//编辑单选题
	public function question_dan_runedit(){
		if (!IS_AJAX){
			$this->error("提交方式错误！",U('qust_danlist'),0);
		}else{
			$question_list=M('question_list');
			if (!$question_list->autoCheckToken($_POST)){
				$this->error('表单令牌错误,刷新页面尝试恢复',U('qust_danlist'),0);
			}else{
				$sl_data=array(
						'question_list_id'=>I('question_list_id'),
						'question_list_subid'=>I('question_list_subid'),
						'question_list_var'=>I('question_list_var'),
						'question_list_op1'=>I('question_list_op1'),
						'question_list_op2'=>I('question_list_op2'),
						'question_list_op3'=>I('question_list_op3'),
						'question_list_op4'=>I('question_list_op4'),
						'question_list_ans'=>I('e_question_list_ans'),
				);
				$question_list->field('question_list_id,question_list_subid,question_list_type,question_list_var,question_list_op1,question_list_op2,question_list_op3,question_list_op4,question_list_ans')->save($sl_data);
				$this->success('考试题目保存成功',U('qust_danlist'),1);
			}
		}
	}

	//删除单选题
	public function question_dan_del(){
		$p=I('p');
		$question_list_id=I('question_list_id');
		$check_question_list=M('question_list')->where(array('question_list_id'=>$question_list_id))->find();
		if (empty($check_question_list)){
			$this->error('参数不正确',U('qust_danlist'),0);
		}else {
			$check_list_id=M('question_list')->where(array('question_list_id'=>$question_list_id,'question_list_areaid'=>$_SESSION['admin_areaid']))->find();
			if (empty($check_list_id) && $_SESSION['aid']!=1){
				$this->error('你没有删除该题目权限',U('qust_danlist'),0);
			}else {
				M('question_list')->where(array('question_list_id'=>$question_list_id))->delete();
				$this->redirect('qust_danlist', array('p' => $p));
			}
		}
	}
	

/*多选题
 * *******************************************************************************************************
 */
	//多选题列表
	public function qust_duolist(){
		
		if ($_SESSION['aid']!=1){
			$map['question_sub_areaid']=array('eq',$_SESSION['admin_areaid']);
			$map_dan['question_list_areaid']=array('eq',$_SESSION['admin_areaid']);
		}
		$map['question_sub_zt']=array('eq',1);
		$question_sub=M('question_sub')->where($map)->select();
		$this->assign('question_sub',$question_sub);
		
		$question_list=D('Question_list');
		$val=I('val');
		$map_dan['question_list_var']= array('like',"%".$val."%");
		$map_dan['question_list_type']=array('eq',2);
		$count= $question_list->where($map_dan)->count();// 查询满足要求的总记录数
		$Page= new \Think\Page($count,C('DB_PAGENUM'));// 实例化分页类 传入总记录数和每页显示的记录数
		$show= $Page->show();// 分页显示输出
		
		$question_list=$question_list->limit($Page->firstRow.','.$Page->listRows)
			->where($map_dan)->relation(true)->order("question_list_id desc")->select();
		$this->assign('question_list',$question_list);
		$this->assign('page',$show);
		$this->assign('val',$val);
		$this->display();
	}

	//增加多选题
	public function question_duo_runadd(){
		if (!IS_AJAX){
			$this->error("提交方式错误！",U('qust_duolist'),0);
		}else{
			$question_list=M('question_list');
			if (!$question_list->autoCheckToken($_POST)){
				$this->error('表单令牌错误,刷新页面尝试恢复',U('qust_duolist'),0);
			}else{
				$sl_data=array(
						'question_list_subid'=>I('question_list_subid'),
						'question_list_type'=>2,
						'question_list_var'=>I('question_list_var'),
						'question_list_op1'=>I('question_list_op1'),
						'question_list_op2'=>I('question_list_op2'),
						'question_list_op3'=>I('question_list_op3'),
						'question_list_op4'=>I('question_list_op4'),
						'question_list_op5'=>I('question_list_op5'),
						'question_list_op6'=>I('question_list_op6'),
						'question_list_addtime'=>time(),
						'question_list_areaid'=>$_SESSION['admin_areaid'],
				);
				$question_list_ans=I('question_list_ans');
				$ans=array();
				foreach ($question_list_ans as $v){
					$ans[]=$v[0];
				}
				$ansdata=implode(',',$ans);
				$sl_data['question_list_ans']=$ansdata;
				session('question_list_subid',I('question_list_subid'));
				$question_list->field('question_list_subid,question_list_type,question_list_var,question_list_op1,question_list_op2,question_list_op3,question_list_op4,question_list_op5,question_list_op6,question_list_addtime,question_list_areaid,question_list_ans')->add($sl_data);
				$this->success('考试题目保存成功',U('qust_duolist'),1);
			}
		}
	}

	//编辑多选题
	public function question_duo_runedit(){
		if (!IS_AJAX){
			$this->error("提交方式错误！",U('qust_duolist'),0);
		}else{
			$question_list=M('question_list');
			if (!$question_list->autoCheckToken($_POST)){
				$this->error('表单令牌错误,刷新页面尝试恢复',U('qust_duolist'),0);
			}else{
				$sl_data=array(
						'question_list_id'=>I('question_list_id'),
						'question_list_subid'=>I('question_list_subid'),
						'question_list_var'=>I('question_list_var'),
						'question_list_op1'=>I('question_list_op1'),
						'question_list_op2'=>I('question_list_op2'),
						'question_list_op3'=>I('question_list_op3'),
						'question_list_op4'=>I('question_list_op4'),
				);
				$question_list_ans=I('e_question_list_ans');
				$ans=array();
				foreach ($question_list_ans as $v){
					$ans[]=$v[0];
				}
				$ansdata=implode(',',$ans);
				$sl_data['question_list_ans']=$ansdata;
				$question_list->field('question_list_id,question_list_subid,question_list_type,question_list_var,question_list_op1,question_list_op2,question_list_op3,question_list_op4,question_list_ans')->save($sl_data);
				$this->success('考试题目保存成功',U('qust_duolist'),1);
			}
		}
	}

	//删除多选题
	public function question_duo_del(){
		$p=I('p');
		$question_list_id=I('question_list_id');
		$check_question_list=M('question_list')->where(array('question_list_id'=>$question_list_id))->find();
		if (empty($check_question_list)){
			$this->error('参数不正确',U('qust_duolist'),0);
		}else {
			$check_list_id=M('question_list')->where(array('question_list_id'=>$question_list_id,'question_list_areaid'=>$_SESSION['admin_areaid']))->find();
			if (empty($check_list_id) && $_SESSION['aid']!=1){
				$this->error('你没有删除该题目权限',U('qust_duolist'),0);
			}else {
				M('question_list')->where(array('question_list_id'=>$question_list_id))->delete();
				$this->redirect('qust_duolist', array('p' => $p));
			}
		}
	}
	

	/*判断题
	 * *******************************************************************************************************
	 */
	//判断题列表
	public function qust_panlist(){
		$val=I('val');
		if ($_SESSION['aid']!=1){
			$map['question_sub_areaid']=array('eq',$_SESSION['admin_areaid']);
			$map_dan['question_list_areaid']=array('eq',$_SESSION['admin_areaid']);
		}
		$map_dan['question_list_var']= array('like',"%".$val."%");
		$map['question_sub_zt']=array('eq',1);
		$question_sub=M('question_sub')->where($map)->select();
		$this->assign('question_sub',$question_sub);
		
		$question_list=D('Question_list');
		$map_dan['question_list_type']=array('eq',3);
		$count= $question_list->where($map_dan)->count();// 查询满足要求的总记录数
		$Page= new \Think\Page($count,C('DB_PAGENUM'));// 实例化分页类 传入总记录数和每页显示的记录数
		$show= $Page->show();// 分页显示输出
		
		$question_list=$question_list->limit($Page->firstRow.','.$Page->listRows)
			->where($map_dan)->relation(true)->order("question_list_id desc")->select();
		$this->assign('question_list',$question_list);
		$this->assign('page',$show);
		$this->assign('val',$val);
		$this->display();
	}

	//增加判断题
	public function question_pan_runadd(){
		if (!IS_AJAX){
			$this->error("提交方式错误！",U('qust_panlist'),0);
		}else{
			$question_list=M('question_list');
			if (!$question_list->autoCheckToken($_POST)){
				$this->error('表单令牌错误,刷新页面尝试恢复',U('qust_panlist'),0);
			}else{
				$sl_data=array(
						'question_list_subid'=>I('question_list_subid'),
						'question_list_type'=>3,
						'question_list_var'=>I('question_list_var'),
						'question_list_ans'=>I('question_list_ans'),
						'question_list_addtime'=>time(),
						'question_list_areaid'=>$_SESSION['admin_areaid'],
				);
				session('question_list_subid',I('question_list_subid'));
				$question_list->field('question_list_subid,question_list_type,question_list_var,question_list_ans,question_list_addtime,question_list_areaid')->add($sl_data);
				$this->success('考试题目保存成功',U('qust_panlist'),1);
			}
		}
	}

	//编辑判断题
	public function question_pan_runedit(){
		if (!IS_AJAX){
			$this->error("提交方式错误！",U('qust_panlist'),0);
		}else{
			$question_list=M('question_list');
			if (!$question_list->autoCheckToken($_POST)){
				$this->error('表单令牌错误,刷新页面尝试恢复',U('qust_panlist'),0);
			}else{
				$sl_data=array(
						'question_list_id'=>I('question_list_id'),
						'question_list_subid'=>I('question_list_subid'),
						'question_list_var'=>I('question_list_var'),
						'question_list_ans'=>I('e_question_list_ans'),
				);

				$question_list->field('question_list_id,question_list_subid,question_list_var,question_list_ans')->save($sl_data);
				$this->success('考试题目保存成功',U('qust_panlist'),1);
			}
		}
	}

	//删除判断题
	public function question_pan_del(){
		$p=I('p');
		$question_list_id=I('question_list_id');
		$check_question_list=M('question_list')->where(array('question_list_id'=>$question_list_id))->find();
		if (empty($check_question_list)){
			$this->error('参数不正确',U('qust_panlist'),0);
		}else {
			$check_list_id=M('question_list')->where(array('question_list_id'=>$question_list_id,'question_list_areaid'=>$_SESSION['admin_areaid']))->find();
			if (empty($check_list_id) && $_SESSION['aid']!=1){
				$this->error('你没有删除该题目权限',U('qust_panlist'),0);
			}else {
				M('question_list')->where(array('question_list_id'=>$question_list_id))->delete();
				$this->redirect('qust_panlist', array('p' => $p));
			}
		}
	}

/***********************************************************************************/
	//填空题
	public function qust_tianlist(){

		//搜索
		$question_list_var=I("post.question_list_var");
		if(isset($_POST["question_list_var"]) && $question_list_var!= ""){
			$condition['question_list_var']  = array('like','%'.$question_list_var.'%');
		}

		//科目列表
		$map['question_sub_zt']=array('eq',1);
		$question_sub=M('question_sub')->where($map)->select();
		$this->assign('question_sub',$question_sub);

		//填空题列表
		$question_list = D('Question_list');
		$map_tian['question_list_type']=array('eq',4);
		$question_list = $question_list->where($condition)->where($map_tian)->relation(true)->order("question_list_id desc")->select();
		//dump($question_list);
		$this->assign('question_list',$question_list);

		$this->display();
	}

	//增加填空题
	public function question_tian_runadd(){
		if (!IS_AJAX){
			$this->error("提交方式错误！",U('qust_tianlist'),0);
		}else{
			$question_list=M('question_list');
			if (!$question_list->autoCheckToken($_POST)){
				$this->error('表单令牌错误,刷新页面尝试恢复',U('qust_duolist'),0);
			}else{
				$sl_data=array(
					'question_list_subid'=>I('question_list_subid'),
					'question_list_type'=>4,
					'question_list_var'=>I('question_list_var'),
					'question_list_addtime'=>time(),
					'question_list_areaid'=>$_SESSION['admin_areaid'],
				);
				$question_list_ans=I('question_list_ans');
				$ans=array();
				foreach ($question_list_ans as $v){
					$ans[]=$v;
				}
				$ansdata=implode(',',$ans);
				$sl_data['question_list_ans']=$ansdata;
				session('question_list_subid',I('question_list_subid'));
				$question_list->add($sl_data);
				$this->success('考试题目保存成功',U('qust_tianlist'),1);
			}
		}
	}

	//修改填空题
	public function question_tian_runedit(){
		if (!IS_AJAX){
			$this->error("提交方式错误！",U('qust_tianlist'),0);
		}else{
			$question_list=M('question_list');
			if (!$question_list->autoCheckToken($_POST)){
				$this->error('表单令牌错误,刷新页面尝试恢复',U('qust_tianlist'),0);
			}else{
				$sl_data=array(
					'question_list_id'=>I('question_list_id'),
					'question_list_subid'=>I('question_list_subid'),
					'question_list_type'=>4,
					'question_list_var'=>I('question_list_var'),
					'question_list_addtime'=>time(),
					'question_list_areaid'=>$_SESSION['admin_areaid'],
				);
				$question_list_ans=I('question_list_ans');
				$ans=array();
				foreach ($question_list_ans as $v){
					$ans[]=$v;
				}
				$ansdata=implode(',',$ans);
				$sl_data['question_list_ans']=$ansdata;
				session('question_list_subid',I('question_list_subid'));
				$question_list->save($sl_data);
				$this->success('考试题目保存成功',U('qust_tianlist'),1);
			}
		}
	}

	//删除填空题
	public function question_tian_del(){
		$p=I('p');
		$question_list_id=I('question_list_id');
		$check_question_list=M('question_list')->where(array('question_list_id'=>$question_list_id))->find();
		if (empty($check_question_list)){
			$this->error('参数不正确',U('qust_tianlist'),0);
		}else {
			$check_list_id=M('question_list')->where(array('question_list_id'=>$question_list_id,'question_list_areaid'=>$_SESSION['admin_areaid']))->find();
			if (empty($check_list_id) && $_SESSION['aid']!=1){
				$this->error('你没有删除该题目权限',U('qust_tianlist'),0);
			}else {
				M('question_list')->where(array('question_list_id'=>$question_list_id))->delete();
				$this->redirect('qust_tianlist', array('p' => $p));
			}
		}
	}

	/***********************************************************************************/
	//问答题
	public function qust_wenlist(){

		//搜索
		$question_list_var=I("post.question_list_var");
		if(isset($_POST["question_list_var"]) && $question_list_var!= ""){
			$condition['question_list_var']  = array('like','%'.$question_list_var.'%');
		}

		//科目列表
		$map['question_sub_zt']=array('eq',1);
		$question_sub=M('question_sub')->where($map)->select();
		$this->assign('question_sub',$question_sub);

		//填空题列表
		$question_list = D('Question_list');
		$map_tian['question_list_type']=array('eq',5);
		$question_list = $question_list->where($condition)->where($map_tian)->relation(true)->order("question_list_id desc")->select();
		//dump($question_list);
		$this->assign('question_list',$question_list);

		$this->display();
	}

	//增加问答题
	public function question_wen_runadd(){
		if (!IS_AJAX){
			$this->error("提交方式错误！",U('qust_wenlist'),0);
		}else{
			$question_list=M('question_list');
			if (!$question_list->autoCheckToken($_POST)){
				$this->error('表单令牌错误,刷新页面尝试恢复',U('qust_wenlist'),0);
			}else{
				$sl_data=array(
					'question_list_subid'=>I('question_list_subid'),
					'question_list_type'=>5,
					'question_list_var'=>I('question_list_var'),
					'question_list_addtime'=>time(),
					'question_list_areaid'=>$_SESSION['admin_areaid'],
				);
				$question_list_ans=I('question_list_ans');

				$sl_data['question_list_ans']=$question_list_ans;
				session('question_list_subid',I('question_list_subid'));
				$question_list->add($sl_data);
				$this->success('考试题目保存成功',U('qust_wenlist'),1);
			}
		}
	}

	//修改问答题
	public function question_wen_runedit(){
		if (!IS_AJAX){
			$this->error("提交方式错误！",U('qust_wenlist'),0);
		}else{
			$question_list=M('question_list');
			if (!$question_list->autoCheckToken($_POST)){
				$this->error('表单令牌错误,刷新页面尝试恢复',U('qust_wenlist'),0);
			}else{
				$sl_data=array(
					'question_list_id'=>I('question_list_id'),
					'question_list_subid'=>I('question_list_subid'),
					'question_list_type'=>5,
					'question_list_var'=>I('question_list_var'),
					'question_list_addtime'=>time(),
					'question_list_areaid'=>$_SESSION['admin_areaid'],
				);
				$question_list_ans=I('question_list_ans');

				$sl_data['question_list_ans']=$question_list_ans;
				session('question_list_subid',I('question_list_subid'));
				$question_list->save($sl_data);
				$this->success('考试题目保存成功',U('qust_wenlist'),1);
			}
		}
	}

	//删除问答题
	public function question_wen_del(){
		$p=I('p');
		$question_list_id=I('question_list_id');
		$check_question_list=M('question_list')->where(array('question_list_id'=>$question_list_id))->find();
		if (empty($check_question_list)){
			$this->error('参数不正确',U('qust_wenlist'),0);
		}else {
			$check_list_id=M('question_list')->where(array('question_list_id'=>$question_list_id,'question_list_areaid'=>$_SESSION['admin_areaid']))->find();
			if (empty($check_list_id) && $_SESSION['aid']!=1){
				$this->error('你没有删除该题目权限',U('qust_wenlist'),0);
			}else {
				M('question_list')->where(array('question_list_id'=>$question_list_id))->delete();
				$this->redirect('qust_wenlist', array('p' => $p));
			}
		}
	}


/***********************************************************************************/
	//科目列表
	public function qust_subject(){
		$question_sub=D('Question_sub');
		if ($_SESSION['aid']!=1){
			$map['question_sub_areaid']=array('eq',$_SESSION['admin_areaid']);
		}
		$val=I('val');
		$map['question_sub_title']= array('like',"%".$val."%");
		
		$question_sub_list=$question_sub->where($map)->order('question_sub_addtime')->relation(true)->select();
		$this->assign('question_sub_list',$question_sub_list);
		$this->assign('val',$val);
		$this->display();
	}

	//增加科目
	public function question_sub_runadd(){
		if (!IS_AJAX){
			$this->error("提交方式错误！",U('qust_subject'),0);
		}else{
			$question_sub=M('question_sub');
			if (!$question_sub->autoCheckToken($_POST)){
				$this->error('表单令牌错误,刷新页面尝试恢复',U('qust_subject'),0);
			}else{
				$check_sub=$question_sub->where(array('question_sub_title'=>I('question_sub_title'),'question_sub_areaid'=>$_SESSION['admin_areaid']))->find();
				if (!empty($check_sub)){
					$this->error("考试科目重复，请重新添加！",U('qust_subject'),0);
				}else{
					$sl_data=array(
							'question_sub_title'=>I('question_sub_title'),
							'question_sub_addtime'=>time(),
							'question_sub_areaid'=>$_SESSION['admin_areaid'],
					);
					$question_details_id=$question_sub->field('question_sub_title,question_sub_addtime,question_sub_areaid')->add($sl_data);
					$details_data=array(
						'question_details_subid'=>$question_details_id,
						'question_details_areaid'=>$_SESSION['admin_areaid'],
					);
					M('question_details')->field('question_details_subid')->add($details_data);
					$this->success('考试科目保存成功',U('qust_subject'),1);
				}
			}
		}
	}

	//删除科目
	public function question_sub_del(){
		$p=I('p');
		$question_sub_id=I('question_sub_id');
		$check_question_sub=M('question_sub')->where(array('question_sub_id'=>$question_sub_id))->find();
		if (empty($check_question_sub)){
			$this->error('参数不正确',U('qust_subject'),0);
		}else {
			$check_sub_nid=M('question_sub')->where(array('question_sub_id'=>$question_sub_id,'question_sub_areaid'=>$_SESSION['admin_areaid']))->find();
			if (empty($check_sub_nid) && $_SESSION['aid']!=1){
				$this->error('你没有删除该考试科目权限',U('qust_subject'),0);
			}else {
				M('question_sub')->where(array('question_sub_id'=>$question_sub_id))->delete();
				$this->redirect('qust_subject', array('p' => $p));
			}
		}
	}

	//编辑科目
	public function question_sub_runedit(){
		if (!IS_AJAX){
			$this->error("提交方式错误！",U('qust_subject'),0);
		}else{
			$question_sub=M('question_sub');
			if (!$question_sub->autoCheckToken($_POST)){
				$this->error('表单令牌错误,刷新页面尝试恢复',U('qust_subject'),0);
			}else{
				$sl_data=array(
					'question_sub_id'=>I('question_sub_id'),
					'question_sub_title'=>I('question_sub_title'),
				);
				$question_sub->field('question_sub_id,question_sub_title')->save($sl_data);
				$this->success('考试科目保存成功',U('qust_subject'),1);
			}
		}
	}

	//设置科目信息
	public function question_sub_set(){
		$question_sub_id=I('question_sub_id');
		$question_details=M('question_details');
		$question_details_list=$question_details->where(array('question_details_subid'=>$question_sub_id))->find();
		
		$sl_data['question_details_id']=$question_details_list['question_details_id'];
		$sl_data['question_details_time']=$question_details_list['question_details_time'];
		$sl_data['question_details_dan']=$question_details_list['question_details_dan'];
		$sl_data['question_details_dannum']=$question_details_list['question_details_dannum'];
		
		$sl_data['question_details_duo']=$question_details_list['question_details_duo'];
		$sl_data['question_details_duonum']=$question_details_list['question_details_duonum'];
		
		$sl_data['question_details_pan']=$question_details_list['question_details_pan'];
		$sl_data['question_details_pannum']=$question_details_list['question_details_pannum'];

		$sl_data['question_details_tian']=$question_details_list['question_details_tian'];
		$sl_data['question_details_tiannum']=$question_details_list['question_details_tiannum'];

		$sl_data['question_details_wen']=$question_details_list['question_details_wen'];
		$sl_data['question_details_wennum']=$question_details_list['question_details_wennum'];

		$sl_data['question_details_starttime']=date('Y-m-d',$question_details_list['question_details_starttime']);
		$sl_data['question_details_endtime']=date('Y-m-d',$question_details_list['question_details_endtime']);
		
		$sl_data['question_details_countnum']=$question_details_list['question_details_countnum'];
		
		$sl_data['status']  = 1;
		$this->ajaxReturn($sl_data,'json');
		
	}

	//编辑科目基本信息
	public function question_set_runedit(){
		if (!IS_AJAX){
			$this->error("提交方式错误！",U('qust_subject'),0);
		}else{
			$question_details=M('question_details');
			if (!$question_details->autoCheckToken($_POST)){
				$this->error('表单令牌错误,刷新页面尝试恢复',U('qust_subject'),0);
			}else{
				$sl_data=array(
						'question_details_id'=>I('question_details_id'),
						'question_details_time'=>I('question_details_time'),
						'question_details_dan'=>I('question_details_dan'),
						'question_details_dannum'=>I('question_details_dannum'),
						
						'question_details_duo'=>I('question_details_duo'),
						'question_details_duonum'=>I('question_details_duonum'),
						
						'question_details_pan'=>I('question_details_pan'),
						'question_details_pannum'=>I('question_details_pannum'),

						'question_details_tian'=>I('question_details_tian'),
						'question_details_tiannum'=>I('question_details_tiannum'),

						'question_details_wen'=>I('question_details_wen'),
						'question_details_wennum'=>I('question_details_wennum'),

						'question_details_countnum'=>I('question_details_countnum'),
				);
				$sldate=I('reservation','');
				$arr = explode(" - ",$sldate);
				$arrdateone=strtotime($arr[0]);
				$arrdatetwo=strtotime($arr[1].' 23:59:59');
				
				$sl_data['question_details_starttime']=$arrdateone;
				$sl_data['question_details_endtime']=$arrdatetwo;
				
				$question_details->save($sl_data);
				$this->success('试卷设置成功',U('qust_subject'),1);
			}
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}