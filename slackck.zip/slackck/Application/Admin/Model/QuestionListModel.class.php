<?php
namespace Admin\Model;
use Think\Model\RelationModel;

 class QuestionListModel extends RelationModel{
   protected $_link=array(
       'area_list' => array(
			'mapping_type'  => self::BELONGS_TO,
			'class_name'    => 'area_list',
			'foreign_key'   => 'question_list_areaid',
			'as_fields'  => 'area_list_name',
		),
   		
   		'question_sub' => array(
   			'mapping_type'  => self::BELONGS_TO,
   			'class_name'    => 'question_sub',
   			'foreign_key'   => 'question_list_subid',
   			'as_fields'  => 'question_sub_title',
   		),
   );

}




?>