<?php
namespace Admin\Model;
use Think\Model\RelationModel;

 class MemberListModel extends RelationModel{
   protected $_link=array(
       'dep_list' => array(
		'mapping_type'  => self::BELONGS_TO,
		'class_name'    => 'dep_list',
		'foreign_key'   => 'member_list_depid',
		'as_fields'  => 'dep_list_name',
		),
   		
   		'area_list' => array(
   				'mapping_type'  => self::BELONGS_TO,
   				'class_name'    => 'area_list',
   				'foreign_key'   => 'member_list_areaid',
   				'as_fields'  => 'area_list_name',
   		),
   );

}




?>