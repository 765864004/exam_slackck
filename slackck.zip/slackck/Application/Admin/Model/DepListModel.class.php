<?php
namespace Admin\Model;
use Think\Model\RelationModel;

 class DepListModel extends RelationModel{
   protected $_link=array(
       'area_list' => array(
		'mapping_type'  => self::BELONGS_TO,
		'class_name'    => 'area_list',
		'foreign_key'   => 'dep_list_areaid',
		'as_fields'  => 'area_list_name',
		),
   );

}




?>