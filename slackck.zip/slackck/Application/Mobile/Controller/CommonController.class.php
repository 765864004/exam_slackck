<?php
namespace Mobile\Controller;
use Think\Controller;
use LT\ThinkSDK\ThinkOauth;
use Event\TypeEvent;

class CommonController extends Controller {
	Public function _initialize(){
		session('se',I('se'));
		if (empty($_SESSION['member_list_id'])){
			$this->error('还没有登录，正在跳转到登录页',U('Home/Login/login'));
		}
	}
}