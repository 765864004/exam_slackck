<?php
namespace Mobile\Controller;
use Think\Controller;

class HelpController extends Controller {
    public function soft(){
		$this->display();
    }

}