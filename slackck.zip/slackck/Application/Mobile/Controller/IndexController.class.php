<?php
namespace Mobile\Controller;
use Think\Controller;


class IndexController extends CommonController {
    public function index(){

        $question_sub_title=I("post.question_sub_title");
        if(isset($_POST["question_sub_title"])&$question_sub_title!= ""){
            $condition['question_sub_title']  = array('like','%'.$question_sub_title.'%');
        }
        $member=M('member_score');
        $member_id = session('member_list_id');
        //echo $member_id;

        $exam_score = $member->where($condition)
            ->where(array('member_score_memberid'=>$member_id))
            ->join("LEFT JOIN mr_question_sub ON mr_member_score.member_score_subid = mr_question_sub.question_sub_id")
            ->join("LEFT JOIN mr_member_list ON mr_member_score.member_score_memberid = mr_member_list.member_list_id")
            ->field("mr_member_score.*, mr_question_sub.question_sub_title, mr_member_list.member_list_realname")
            ->order("member_score_id desc")
            ->select();
        //dump($exam_score);
        $this->assign("exam_score", $exam_score);

		$this->display();
    }

    public function userinfo(){
        $this->display();
    }

    public function exammange(){
        $this->display();
    }

    public function me(){
        $this->display();
    }


}