<?php
namespace Mobile\Controller;
use Think\Controller;


class ExamController extends CommonController {

	public function exam_list(){
		$question_details = M('question_details');

		$count= M('question_sub')->count();// 查询满足要求的总记录数
		$Page= new \Think\Page($count,10);// 实例化分页类 传入总记录数和每页显示的记录数
		$show= $Page->show();// 分页显示输出
		
		$question_sub=D('Question_sub')->limit($Page->firstRow.','.$Page->listRows)->order('question_sub_addtime')->select();

		$member_list_id = $_SESSION['member_list_id'];

		foreach($question_sub as $k=>&$v){
			$question_sub_id = $v["question_sub_id"];
			//每个科目最大分
			$member_score = D('Member_score')->where(array('member_score_memberid'=>$member_list_id, 'member_score_subid'=>$question_sub_id))->Max('member_score_num');
			$v["max_score"] = $member_score;

			//试卷详情
			$details = $question_details->where(array('question_details_subid'=>$question_sub_id))->find();
			$v["jige"] = $member_score/$details["question_details_countnum"];
			$v["question_details_time"]=$details["question_details_time"];
			$v["question_details_dan"]=$details["question_details_dan"];
			$v["question_details_dannum"]=$details["question_details_dannum"];
			$v["question_details_duo"]=$details["question_details_duo"];
			$v["question_details_duonum"]=$details["question_details_duonum"];
			$v["question_details_pan"]=$details["question_details_pan"];
			$v["question_details_pannum"]=$details["question_details_pannum"];
			$v["question_details_tian"]=$details["question_details_tian"];
			$v["question_details_tiannum"]=$details["question_details_tiannum"];
			$v["question_details_wen"]=$details["question_details_wen"];
			$v["question_details_wennum"]=$details["question_details_wennum"];

			$v["question_details_countnum"]=$details["question_details_countnum"];
			$v["question_details_starttime"]=$details["question_details_starttime"];
			$v["question_details_endtime"]=$details["question_details_endtime"];
			$v["question_details_addtime"]=$details["question_details_addtime"];
		}

		//p($question_sub);
		$this->assign('question_sub',$question_sub);
		$this->assign('page',$show);
		$this->display();
	}

	//分配试卷
	public function exam_run(){
		$question_sub_id=I('question_sub_id');
		$question_details=M('question_details');
		$question_sub=D('Question_sub');
		$question_list=M('question_list');

		//科目
		$sub_list=$question_sub->where(array('question_sub_id'=>$question_sub_id))->find();

		//各题型数量 detail
		$details = $question_details->where(array('question_details_subid'=>$question_sub_id))->find();
		$sub_list["question_details_time"]=$details["question_details_time"];
		$sub_list["question_details_dan"]=$details["question_details_dan"];
		$sub_list["question_details_dannum"]=$details["question_details_dannum"];
		$sub_list["question_details_duo"]=$details["question_details_duo"];
		$sub_list["question_details_duonum"]=$details["question_details_duonum"];
		$sub_list["question_details_pan"]=$details["question_details_pan"];
		$sub_list["question_details_pannum"]=$details["question_details_pannum"];
		$sub_list["question_details_tian"]=$details["question_details_tian"];
		$sub_list["question_details_tiannum"]=$details["question_details_tiannum"];
		$sub_list["question_details_wen"]=$details["question_details_wen"];
		$sub_list["question_details_wennum"]=$details["question_details_wennum"];
		$sub_list["question_details_countnum"]=$details["question_details_countnum"];
		$sub_list["question_details_starttime"]=$details["question_details_starttime"];
		$sub_list["question_details_endtime"]=$details["question_details_endtime"];
		$sub_list["question_details_addtime"]=$details["question_details_addtime"];
		$this->assign('sub_list',$sub_list);
		
		$map['question_list_subid']=array('eq',$question_sub_id); //科目（以后改为类别）
		$map_1['question_list_type']=array('eq',1); //单选题
		$map_2['question_list_type']=array('eq',2); //多选题
		$map_3['question_list_type']=array('eq',3); //判断题
		$map_4['question_list_type']=array('eq',4); //填空题
		$map_5['question_list_type']=array('eq',5); //问答题

		//单选题
		if($sub_list['question_details_dan'] != 0) {
			$list_list_1 = $question_list->where($map)->where($map_1)->limit($sub_list['question_details_dan'])->order('rand()')->select();
			foreach ($list_list_1 as $k => &$v) {
				$v["question_list_op"][0] = "A、" . $v["question_list_op1"];
				$v["question_list_op"][1] = "B、" . $v["question_list_op2"];
				$v["question_list_op"][2] = "C、" . $v["question_list_op3"];
				if (!empty($v["question_list_op4"]) || $v["question_list_op4"] === 0) {
					$v["question_list_op"][3] = "D、" . $v["question_list_op4"];
				}
			}
		}
		$this->assign('list_list_1',$list_list_1);

		//多选题
		if($sub_list['question_details_duo'] != 0) {
			$list_list_2 = $question_list->where($map)->where($map_2)->limit($sub_list['question_details_duo'])->order('rand()')->select();
		}
		$this->assign('list_list_2',$list_list_2);

		//判断题
		if($sub_list['question_details_pan'] != 0) {
			$list_list_3 = $question_list->where($map)->where($map_3)->limit($sub_list['question_details_pan'])->order('rand()')->select();
		}
		$this->assign('list_list_3',$list_list_3);

		//填空题
		if($sub_list['question_details_tian'] != 0){
			$list_list_4=$question_list->where($map)->where($map_4)->limit($sub_list['question_details_tian'])->order('rand()')->select();
			foreach($list_list_4 as $k=>&$v){
				$v["ans"]=explode(',', $v["question_list_ans"]);
				foreach($v["ans"] as $k2=>&$v2){
					if(isset($v2)){
						$v2=1;
					}
				}
			}
		}
		$this->assign('list_list_4',$list_list_4);

		//问答题
		if($sub_list['question_details_wen'] != 0) {
			$list_list_5 = $question_list->where($map)->where($map_5)->limit($sub_list['question_details_wen'])->order('rand()')->select();
		}
		$this->assign('list_list_5',$list_list_5);

		$this->display();
	}
	
	//计算总分
	public function exam_runadd(){
		//p($_POST);exit;
		$question_sub_id=I('question_sub_id'); //科目id
		$count_num="0"; //总分
		$question_list=M('question_list'); //题库
		$question_details=M('question_details'); //试题详情
		$details_list=M('question_details')->where(array('question_details_subid'=>$question_sub_id))->find(); //试题数量  每题分值

		$false_arr = array();

		foreach ($_POST as $v=>$y){
			//$y为答案
			$type=substr($v,0,3);//截取字符串，判断题型   输出结果为 dan duo  pan

			//单选题
			if ($type=='dan'){
				$d_id=trim(substr($v,6,100));
				$check_num_1=$question_list->where(array('question_list_id'=>$d_id,'question_list_ans'=>$y))->find();
				if (!empty($check_num_1)){//如果用户提交的数据在表中查询到，说明题目回答是正确的
					$count_num=$count_num+$details_list['question_details_dannum'];
				}else{
					$false_arr[] = $d_id;
				}
			}

			//多选题
			if ($type=='duo'){
				$flag=array();
    			foreach ($y as $j){
    				$flag[]=$j[0];
    			}
				//p($flag);exit;
    			$ans_all=implode(',',$flag);//最终得到答案的字符串 a,b,c,d
    			$e_id=trim(substr($v,6,100));
    			$check_num_2=$question_list->where(array('question_list_id'=>$e_id,'question_list_ans'=>$ans_all))->find();
    			if (!empty($check_num_2)){//如果用户提交的数据在表中查询到，说明题目回答是正确的
    				$count_num=$count_num+$details_list['question_details_duonum'];
    			}else{
					$false_arr[] = $e_id;
				}
			}

			//判断题
			if ($type=='pan'){
				$f_id=trim(substr($v,6,100));
				$check_num_3=$question_list->where(array('question_list_id'=>$f_id,'question_list_ans'=>$y))->find();
				if (!empty($check_num_3)){//如果用户提交的数据在表中查询到，说明题目回答是正确的
					$count_num=$count_num+$details_list['question_details_pannum'];
				}else{
					$false_arr[] = $f_id;
				}
			}

			//填空题
			if($type=='tia'){
				$arr = array();
				foreach($y as $z){
					$arr[] = $z;
				}
				$ans_tian = implode(',',$arr);
				$g_id=trim(substr($v,7,100)); //题目id
				$check_num_4=$question_list->where(array('question_list_id'=>$g_id,))->find();
				//如果字符串相等
				if(strcasecmp($ans_tian, $check_num_4["question_list_ans"]) == 0){
					$count_num=$count_num+$details_list['question_details_tiannum'];
				}else{
					$false_arr[] = $g_id;
				}
			}

			//问答题
			if($type=='wen'){
				$h_id=trim(substr($v,6,100)); //题目id
				$check_num_5=$question_list->where(array('question_list_id'=>$h_id,))->find();
				//如果字符串相等
				if(strcasecmp($y, $check_num_5["question_list_ans"]) == 0){
					$count_num=$count_num+$details_list['question_details_wennum'];
				}else{
					$false_arr[] = $h_id;
				}
			}

		}
		session('false_arr', $false_arr);

		//echo $count_num;exit;
		//查询学员 是否考过当前科目
		$member_score=M('member_score');
		$check_score=$member_score->where(array('member_score_subid'=>$question_sub_id,'member_score_memberid'=>$_SESSION['member_list_id']))->find();
		//若没考过当前科目
		if(empty($check_score)){
			$sl_data=array(
					'member_score_subid'=>$question_sub_id, //科目
					'member_score_memberid'=>$_SESSION['member_list_id'], //学员id
					'member_score_num'=>$count_num,  //总分
					'member_score_time'=>time(),
			);
			//p($sl_data);
			$member_score->add($sl_data);
			$this->success('试卷提交成功,您的分数为'.$count_num,U('exam_list'),3);
		//若考过当前科目 且当前分数大于上次分数
		}elseif ($count_num>=$check_score['member_score_num']){
			$sl_data=array(
					'member_score_id'=>$check_score['member_score_id'],
					'member_score_subid'=>$question_sub_id,
					'member_score_memberid'=>$_SESSION['member_list_id'],
					'member_score_num'=>$count_num,
					'member_score_time'=>time(),
			);
			//p($sl_data);
			$member_score->save($sl_data);
			$this->success('试卷提交成功,您的分数为'.$count_num,U('exam_list'),3);
		//若考过当前科目 且当前分数小于上次分数
		}else{
			$this->success('此次答案得分为'.$count_num.'，没有大于你目前的答案分数，不予保存',U('exam_list'),3);
		}
	}

	//成绩查询
	public function exam_score(){

		//搜索
		$question_sub_title=I("post.question_sub_title");
		if(isset($_POST["question_sub_title"])&$question_sub_title!= ""){
			$condition['question_sub_title']  = array('like','%'.$question_sub_title.'%');
		}
		$member=M('member_score');
		$member_id = session('member_list_id');
		//echo $member_id;

		$exam_score = $member->where($condition)
			->where(array('member_score_memberid'=>$member_id))
			->join("LEFT JOIN mr_question_sub ON mr_member_score.member_score_subid = mr_question_sub.question_sub_id")
			->join("LEFT JOIN mr_member_list ON mr_member_score.member_score_memberid = mr_member_list.member_list_id")
			->field("mr_member_score.*, mr_question_sub.question_sub_title, mr_member_list.member_list_realname")
			->order("member_score_id desc")
			->select();
		//dump($exam_score);
		$this->assign("exam_score", $exam_score);
		$this->display();
	}


	//分配试卷
	public function exam_run_tea(){
		$question_sub_id=I('question_sub_id');
		$question_details=M('question_details');
		$question_sub=D('Question_sub');
		$question_list=M('question_list');

		//科目
		$sub_list=$question_sub->where(array('question_sub_id'=>$question_sub_id))->find();

		//各题型数量 detail
		$details = $question_details->where(array('question_details_subid'=>$question_sub_id))->find();
		$sub_list["question_details_time"]=$details["question_details_time"];
		$sub_list["question_details_dan"]=$details["question_details_dan"];
		$sub_list["question_details_dannum"]=$details["question_details_dannum"];
		$sub_list["question_details_duo"]=$details["question_details_duo"];
		$sub_list["question_details_duonum"]=$details["question_details_duonum"];
		$sub_list["question_details_pan"]=$details["question_details_pan"];
		$sub_list["question_details_pannum"]=$details["question_details_pannum"];
		$sub_list["question_details_tian"]=$details["question_details_tian"];
		$sub_list["question_details_tiannum"]=$details["question_details_tiannum"];
		$sub_list["question_details_wen"]=$details["question_details_wen"];
		$sub_list["question_details_wennum"]=$details["question_details_wennum"];
		$sub_list["question_details_countnum"]=$details["question_details_countnum"];
		$sub_list["question_details_starttime"]=$details["question_details_starttime"];
		$sub_list["question_details_endtime"]=$details["question_details_endtime"];
		$sub_list["question_details_addtime"]=$details["question_details_addtime"];
		$this->assign('sub_list',$sub_list);

		$map['question_list_subid']=array('eq',$question_sub_id); //科目（以后改为类别）
		$map_1['question_list_type']=array('eq',1); //单选题
		$map_2['question_list_type']=array('eq',2); //多选题
		$map_3['question_list_type']=array('eq',3); //判断题
		$map_4['question_list_type']=array('eq',4); //填空题
		$map_5['question_list_type']=array('eq',5); //问答题

		if($sub_list['question_details_dan'] != 0) {
			$list_list_1 = $question_list->where($map)->where($map_1)->limit($sub_list['question_details_dan'])->order('rand()')->select();
			foreach ($list_list_1 as $k => &$v) {
				$v["question_list_op"][0] = "A、" . $v["question_list_op1"];
				$v["question_list_op"][1] = "B、" . $v["question_list_op2"];
				$v["question_list_op"][2] = "C、" . $v["question_list_op3"];
				if (!empty($v["question_list_op4"]) || $v["question_list_op4"] === 0) {
					$v["question_list_op"][3] = "D、" . $v["question_list_op4"];
				}
			}
		}
		$this->assign('list_list_1',$list_list_1);

		if($sub_list['question_details_duo'] != 0) {
			$list_list_2 = $question_list->where($map)->where($map_2)->limit($sub_list['question_details_duo'])->order('rand()')->select();
		}
		$this->assign('list_list_2',$list_list_2);

		if($sub_list['question_details_pan'] != 0) {
			$list_list_3 = $question_list->where($map)->where($map_3)->limit($sub_list['question_details_pan'])->order('rand()')->select();
		}
		$this->assign('list_list_3',$list_list_3);

		if($sub_list['question_details_tian'] != 0) {
			$list_list_4 = $question_list->where($map)->where($map_4)->limit($sub_list['question_details_tian'])->order('rand()')->select();
			foreach ($list_list_4 as $k => &$v) {
				$v["ans"] = explode(',', $v["question_list_ans"]);
				foreach ($v["ans"] as $k2 => &$v2) {
					if (isset($v2)) {
						$v2 = 1;
					}
				}
			}
		}
		$this->assign('list_list_4',$list_list_4);

		if($sub_list['question_details_wen'] != 0) {
			$list_list_5 = $question_list->where($map)->where($map_5)->limit($sub_list['question_details_wen'])->order('rand()')->select();
		}
		$this->assign('list_list_5',$list_list_5);

		$this->display();
	}

	//计算总分
	public function exam_runadd_tea(){
		p($_POST);exit;
		$question_sub_id=I('question_sub_id'); //科目id
		$count_num="0"; //总分
		$question_list=M('question_list'); //题库
		$question_details=M('question_details'); //试题详情
		$details_list=M('question_details')->where(array('question_details_subid'=>$question_sub_id))->find(); //试题数量  每题分值

		foreach ($_POST as $v=>$y){
			//$y为答案
			$type=substr($v,0,3);//截取字符串，判断题型   输出结果为 dan duo pan

			//单选题
			if ($type=='dan'){
				$d_id=trim(substr($v,6,100));
				$check_num_1=$question_list->where(array('question_list_id'=>$d_id,'question_list_ans'=>$y))->find();
				if (!empty($check_num_1)){//如果用户提交的数据在表中查询到，说明题目回答是正确的
					$count_num=$count_num+$details_list['question_details_dannum'];
				}
			}

			//多选题
			if ($type=='duo'){
				$flag=array();
				foreach ($y as $j){
					$flag[]=$j[0];
				}
				//p($flag);exit;
				$ans_all=implode(',',$flag);//最终得到答案的字符串 a,b,c,d
				$e_id=trim(substr($v,6,100));
				$check_num_2=$question_list->where(array('question_list_id'=>$e_id,'question_list_ans'=>$ans_all))->find();
				if (!empty($check_num_2)){//如果用户提交的数据在表中查询到，说明题目回答是正确的
					$count_num=$count_num+$details_list['question_details_duonum'];
				}
			}

			//判断题
			if ($type=='pan'){
				$f_id=trim(substr($v,6,100));
				$check_num_3=$question_list->where(array('question_list_id'=>$f_id,'question_list_ans'=>$y))->find();
				if (!empty($check_num_3)){//如果用户提交的数据在表中查询到，说明题目回答是正确的
					$count_num=$count_num+$details_list['question_details_pannum'];
				}
			}

			//填空题
			if($type=='tia'){
				$arr = array();
				foreach($y as $z){
					$arr[] = $z;
				}
				$ans_tian = implode(',',$arr);
				$g_id=trim(substr($v,7,100)); //题目id
				$check_num_4=$question_list->where(array('question_list_id'=>$g_id,))->find();
				//如果字符串相等
				if(strcasecmp($ans_tian, $check_num_4["question_list_ans"]) == 0){
					$count_num=$count_num+$details_list['question_details_tiannum'];
				}
			}

			//问答题
			if($type=='wen'){
				$h_id=trim(substr($v,6,100)); //题目id
				$check_num_5=$question_list->where(array('question_list_id'=>$h_id,))->find();
				//如果字符串相等
				if(strcasecmp($y, $check_num_5["question_list_ans"]) == 0){
					$count_num=$count_num+$details_list['question_details_wennum'];
				}
			}

		}

		$this->success('此次答案得分为'.$count_num,U('Exam/exam_list'),3);
	}


	//查看正确答案
	public function answer(){
		$question_list_id = I("question_list_id"); //试题id
		if(is_array(I("answer"))){//多选
			$answer = implode(',',I("answer")); //数组合并为字符串
		}else{ //单选
			$answer = I("answer");
		}

		$question_lists = M()->table("mr_question_list")->where(array('question_list_id'=>$question_list_id ))->find();
		if($answer == $question_lists["question_list_ans"]){
			$question_lists["answer"]="正确";
			$question_lists["answer2"]=1;
		}else{
			$question_lists["answer"]="错误";
			$question_lists["answer2"]=0;
		}

		//$question_list["question_list_ans"] =htmlspecialchars_decode($quetion_lists["question_list_ans"]);

//		$res = json_encode($answer); //转换为json格式在发送
//		echo $res;exit;

		$this->ajaxReturn($question_lists,'JSON');

	}


	//查看错题
	public function false(){
		//dump($_SESSION['false_arr']);
		$false_arr = $_SESSION['false_arr'];

		if($false_arr){
			$false_lists = M('question_list')
				->where( array("question_list_id"=>array("in", $false_arr)) )
				->join("LEFT JOIN mr_question_sub ON mr_question_list.question_list_subid = mr_question_sub.question_sub_id")
				->field("mr_question_list.*, mr_question_sub.question_sub_title")
				->select();
		}

		foreach($false_lists as $k=>&$v){
			if($v["question_list_type"] == 1){
				if($v["question_list_ans"] == 'a'){
					$v["standard"] = "A.".$v["question_list_op1"];
				}elseif($v["question_list_ans"] == 'b'){
					$v["standard"] = "B.".$v["question_list_op2"];
				}elseif($v["question_list_ans"] == 'c'){
					$v["standard"] = "C.".$v["question_list_op3"];
				}elseif($v["question_list_ans"] == 'd'){
					$v["standard"] = "D.".$v["question_list_op4"];
				}
			}elseif($v["question_list_type"] == 2){
				$duo ="";
				$arr_ans = explode(',', $v["question_list_ans"]);
				foreach($arr_ans as $kk=>$vv){
					if($vv == 'a'){
						$duo.="A.".$v["question_list_op1"]."</br>";
					}elseif($vv == 'b'){
						$duo.="B.".$v["question_list_op2"]."</br>";
					}elseif($vv == 'c'){
						$duo.="C.".$v["question_list_op3"]."</br>";
					}elseif($vv == 'd'){
						$duo.="D.".$v["question_list_op4"]."</br>";
					}
				}
				$v["standard"] = $duo;
			}elseif($v["question_list_type"] == 3){
				if($v["question_list_ans"] == 1){
					$v["standard"] ="正确";
				}else{
					$v["standard"] ="错误";
				}
			}
		}

		$this->assign("false_lists", $false_lists);
		$this->display();
	}
	
	
	
	
	
	
	
	
}