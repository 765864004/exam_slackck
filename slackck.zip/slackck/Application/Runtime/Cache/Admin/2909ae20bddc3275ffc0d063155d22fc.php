<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
	<head>
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
		<meta charset="utf-8" />
		<title>风河信息科技网络在线考试后台管理系统</title>

		<meta name="description" content="" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />

		<!-- bootstrap & fontawesome -->
		<link rel="stylesheet" href="/Public/assets/css/bootstrap.css" />
		<link rel="stylesheet" href="/Public/assets/css/font-awesome.css" />

		<!-- ace styles -->
		<link rel="stylesheet" href="/Public/assets/css/ace.css" class="ace-main-stylesheet" id="main-ace-style" />

		<!--[if lte IE 9]>
			<link rel="stylesheet" href="/Public/assets/css/ace-part2.css" class="ace-main-stylesheet" />
		<![endif]-->

		<!--[if lte IE 9]>
		  <link rel="stylesheet" href="/Public/assets/css/ace-ie.css" />
		<![endif]-->

		<!-- inline styles related to this page -->
        <link rel="stylesheet" href="/Public/assets/css/slackck.css" />
		<!-- ace settings handler -->
		<script src="/Public/assets/js/ace-extra.js"></script>
		<script src="/Public/assets/js/jquery.min.js"></script>
		<script src="/Public/assets/js/jquery.form.js"></script>
		<script src="/Public/layer/layer.js"></script>
		<!--<script src="/Public/assets/js/jquery.leanModal.min.js"></script>-->

		<!--[if lte IE 8]>
		<script src="/Public/assets/js/html5shiv.js"></script>
		<script src="/Public/assets/js/respond.js"></script>
		<![endif]-->


		<link href="/Public/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
		<script src="/Public/assets/bootstrap/js/bootstrap.min.js"></script>
		<style>
			#hidden{ overflow: hidden;  white-space: nowrap; text-overflow: ellipsis;}
		</style>
	</head>

	<body class="no-skin">
		<!-- #section:basics/navbar.layout -->
		<div id="navbar" class="navbar navbar-default    navbar-collapse">
			<div class="navbar-container" id="navbar-container">
				<!-- /section:basics/sidebar.mobile.toggle -->
				<div class="navbar-header pull-left">
					<!-- #section:basics/navbar.layout.brand -->
					<a href="<?php echo U('Index/index');?>" class="navbar-brand">
						<small>
							<i class="fa fa-leaf"></i>
							网络在线考试后台管理系统
						</small>
					</a>

				</div>

				<!-- #section:basics/navbar.dropdown -->
				<div class="navbar-buttons navbar-header pull-right  collapse navbar-collapse" role="navigation">
					<ul class="nav ace-nav">
					<li class="transparent"></li>
					<li class="transparent">
						<a style="cursor:pointer;" id="cache" class="dropdown-toggle">清除缓存</a>
					</li>
			
						<!-- #section:basics/navbar.user_menu -->
						<li class="light-blue">
							<a data-toggle="dropdown" href="#" class="dropdown-toggle">
								<img class="nav-user-photo" src="/Public/assets/avatars/user.jpg" alt="Jason's Photo" />
								<span class="user-info">
									<small>Welcome,</small>
									<?php echo ($_SESSION['admin_username']); ?>
								</span>

								<i class="ace-icon fa fa-caret-down"></i>
							</a>

							<ul class="user-menu dropdown-menu-right dropdown-menu dropdown-yellow dropdown-caret dropdown-close">
								<li>
									<a href="#">
										<i class="ace-icon fa fa-cog"></i>
										个人设置
									</a>
								</li>

								<li>
									<a href="profile.html">
										<i class="ace-icon fa fa-user"></i>
										会员中心
									</a>
								</li>

								<li class="divider"></li>

								<li>
									<a href="javascript:;"  id="logout">
										<i class="ace-icon fa fa-power-off"></i>
										注销
									</a>
								</li>
							</ul>
						</li>

						<!-- /section:basics/navbar.user_menu -->
					</ul>
				</div>

				<!-- /section:basics/navbar.dropdown -->
			</div><!-- /.navbar-container -->
		</div>


<script type="text/javascript">
$(document).ready(function(){
	$("#logout").click(function(){
		layer.confirm('你确定要退出吗？', {icon: 3}, function(index){
	    layer.close(index);
	    window.location.href="<?php echo U('Login/logout');?>";
	});
	});
});



$(function(){
$('#cache').click(function(){
if(confirm("确认要清除缓存？")){
var $type=$('#type').val();
var $mess=$('#mess');
$.post('/index.php/Admin/Qust/clear',{type:$type},function(data){
alert("缓存清理成功");
});
}else{
return false;
}
});
});
</script>



<!-- /section:basics/navbar.layout -->
<div class="main-container" id="main-container">

    <!-- #section:basics/sidebar -->

    <div id="sidebar" class="sidebar responsive">

    <div class="sidebar-shortcuts" id="sidebar-shortcuts">
        <div class="sidebar-shortcuts-large" id="sidebar-shortcuts-large">
            <button class="btn btn-success">
                <i class="ace-icon fa fa-signal"></i>
            </button>

            <button class="btn btn-info">
                <i class="ace-icon fa fa-pencil"></i>
            </button>

            <!-- #section:basics/sidebar.layout.shortcuts -->
            <button class="btn btn-warning">
                <i class="ace-icon fa fa-users"></i>
            </button>

            <button class="btn btn-danger">
                <i class="ace-icon fa fa-cogs"></i>
            </button>

            <!-- /section:basics/sidebar.layout.shortcuts -->
        </div>

        <div class="sidebar-shortcuts-mini" id="sidebar-shortcuts-mini">
            <span class="btn btn-success"></span>

            <span class="btn btn-info"></span>

            <span class="btn btn-warning"></span>

            <span class="btn btn-danger"></span>
        </div>
    </div><!-- /.sidebar-shortcuts -->

    <ul class="nav nav-list">
        <?php use Common\Controller\AuthController; use Think\Auth; $m = M('auth_rule'); $field = 'id,name,title,css'; $data = $m->field($field)->where('pid=0 AND menustatus=1')->order('sort')->select(); $auth = new Auth(); foreach ($data as $k=>$v){ if(!$auth->check($v['name'], $_SESSION['aid']) && $_SESSION['aid'] != 1){ unset($data[$k]); } } ?>

        <?php if(is_array($data)): foreach($data as $key=>$v): ?><li class="<?php if( CONTROLLER_NAME == $v['name']): ?>active open<?php endif; ?>"><!--open代表打开状态-->
            <a href="#" class="dropdown-toggle">
                <i class="menu-icon fa <?php echo ($v["css"]); ?>"></i>
							<span class="menu-text">
								<?php echo ($v["title"]); ?>
							</span>

                <b class="arrow fa fa-angle-down"></b>
            </a>

            <b class="arrow"></b>

            <ul class="submenu">
                <?php $m = M('auth_rule'); $dataa = $m->where(array('pid'=>$v['id'],'menustatus'=>1))->select(); foreach ($dataa as $kk=>$vv){ if(!$auth->check($vv['name'], $_SESSION['aid']) && $_SESSION['aid'] != 1){ unset($dataa[$kk]); } } ?>
                <?php if(is_array($dataa)): foreach($dataa as $key=>$j): ?><li class="<?php if( ($_SESSION['se'] == $j['id'])): ?>active<?php endif; ?>">
                    <a href="<?php echo U($j['name'],array('se'=>$j['id']));?>">
                        <i class="menu-icon fa fa-caret-right"></i>
                        <?php echo ($j["title"]); ?>
                    </a>
                    <b class="arrow"></b>
                    </li><?php endforeach; endif; ?>
            </ul>
            </li><?php endforeach; endif; ?>

    </ul><!-- /.nav-list -->

    <!-- #section:basics/sidebar.layout.minimize -->
    <div class="sidebar-toggle sidebar-collapse" id="sidebar-collapse">
        <i class="ace-icon fa fa-angle-double-left" data-icon1="ace-icon fa fa-angle-double-left"
           data-icon2="ace-icon fa fa-angle-double-right"></i>
    </div>

    <!-- /section:basics/sidebar.layout.minimize -->
    <script type="text/javascript">
        try {
            ace.settings.check('sidebar', 'collapsed')
        } catch (e) {
        }
    </script>
</div>

    <!-- /section:basics/sidebar -->
    <div class="main-content">
        <div class="main-content-inner">
            <div class="page-content">

                <div class="row maintop">
                    <div class="col-xs-12 col-sm-1">
                        <!-- 点击模态框（Modal） -->
                        <button class="btn btn-xs btn-danger" data-toggle="modal" data-target="#myModal">
                            <i class="ace-icon fa fa-bolt bigger-110"></i>
                            添加科目
                        </button>
                    </div>

                    <div class="col-xs-12 col-sm-5">
                        <form name="admin_list_sea" class="form-search" method="post" action="/index.php/Admin/Qust/qust_subject">
                            <div class="input-group">
										<span class="input-group-addon">
											<i class="ace-icon fa fa-check"></i>
										</span>
                                <input type="text" name="val" id="val" class="form-control search-query admin_sea"
                                       value="<?php echo ($val); ?>" placeholder="输入考试科目名称"/>
										<span class="input-group-btn">
											<button type="submit" class="btn btn-xs  btn-purple">
                                                <span class="ace-icon fa fa-search icon-on-right bigger-110"></span>
                                                搜索
                                            </button>
										</span>
                            </div>
                        </form>
                    </div>
                    <div class="input-group-btn">
                        <a href="/index.php/Admin/Qust/qust_subject">
                            <button type="button" class="btn btn-xs  btn-purple">
                                <span class="ace-icon fa fa-globe icon-on-right bigger-110"></span>
                                显示全部
                            </button>
                        </a>
                    </div>
                </div>

                <div class="row">
                    <div class="col-xs-12">
                        <div>
                            <table width="100%" class="table table-striped table-bordered table-hover"
                                   id="dynamic-table">
                                <thead>
                                <tr>
                                    <th width="4%">ID</th>
                                    <th width="46%">科目名称</th>
                                    <th width="10%">市区县</th>
                                    <th width="22%">添加时间</th>
                                    <th width="18%" style="border-right:#CCC solid 1px;">操作</th>
                                </tr>
                                </thead>

                                <tbody>

                                <?php if(is_array($question_sub_list)): foreach($question_sub_list as $key=>$v): ?><tr>
                                        <td height="28"><?php echo ($v["question_sub_id"]); ?></td>
                                        <td><?php echo ($v["question_sub_title"]); ?></td>
                                        <td><?php echo ($v["area_list_name"]); ?></td>
                                        <td><?php echo (date('Y-m-d H:i:s',$v["question_sub_addtime"])); ?></td>
                                        <td>
                                            <div class="action-buttons">
                                                <a class="info" href="javascript:;"
                                                   onclick="return question_sub_set(<?php echo ($v["question_sub_id"]); ?>);"
                                                   title="设置试卷">设置试卷</a>
                                                <a class="green" href="javascript:;"
                                                   onclick="return question_sub_edit(<?php echo ($v["question_sub_id"]); ?>,'<?php echo ($v["question_sub_title"]); ?>');"
                                                   title="修改">修改</a>
                                                <a class="red" href="javascript:;"
                                                   onclick="return del(<?php echo ($v["question_sub_id"]); ?>,<?php echo I('p',1);?>);"
                                                   title="删除">删除</a></div>
                                        </td>
                                    </tr><?php endforeach; endif; ?>
                                <tr>
                                    <td height="50" colspan="6" align="left"><?php echo ($page); ?></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="breadcrumbs breadcrumbs-fixed" id="breadcrumbs">
    <div class="row">
        <div class="col-xs-12">
            <div class="">
                <div id="sidebar2" class="sidebar h-sidebar navbar-collapse collapse collapse_btn">
                    <ul class="nav nav-list header-nav" id="header-nav">

                        <?php $m = M('auth_rule'); $dataaa = $m->where(array('pid'=>$_SESSION['se'],'menustatus'=>1))->order('sort')->select(); foreach ($dataaa as $kkk=>$vvv){ if(!$auth->check($vvv['name'], $_SESSION['aid']) && $_SESSION['aid']!= 1){ unset($dataaa[$kkk]); } } ?>
                        <?php if(is_array($dataaa)): foreach($dataaa as $key=>$k): ?><li>
                                <a href="<?php echo U(''.$k['name'].'');?>">
                                    <o class="font12 <?php if( (CONTROLLER_NAME. '/'.ACTION_NAME == $k['name'])): ?>rigbg<?php endif; ?>"><?php echo ($k["title"]); ?></o>
                                </a>

                                <b class="arrow"></b>
                            </li><?php endforeach; endif; ?>
                    </ul><!-- /.nav-list -->
                </div><!-- .sidebar -->
            </div>
        </div><!-- /.col -->
    </div><!-- /.row -->

</div>

            </div><!-- /.page-content -->
        </div>
    </div><!-- /.main-content -->

    <!--新增科目 显示模态框（Modal） -->
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <form class="form-horizontal" name="question_sub_runadd" id="question_sub_runadd" method="post"
              action="/index.php/Admin/Qust/question_sub_runadd">
            <div class="modal-dialog" style="width:70%;">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal"
                                aria-hidden="true">×
                        </button>
                        <h4 class="modal-title" id="myModalLabel">
                            添加考试科目</h4>
                    </div>
                    <div class="modal-body">


                        <div class="row">
                            <div class="col-xs-12">

                                <div class="form-group">
                                    <label class="col-sm-2 control-label no-padding-right" for="form-field-1">
                                        考试科目名称： </label>
                                    <div class="col-sm-10">
                                        <input type="text" name="question_sub_title" id="question_sub_title"
                                               placeholder="输入考试科目名称" class="col-xs-10 col-sm-8"/>
                                    </div>
                                </div>
                                <div class="space-4"></div>
                            </div>
                        </div>


                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">
                            提交保存
                        </button>
                        <button class="btn btn-info" type="reset">
                            重置
                        </button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">
                            关闭
                        </button>
                    </div>
                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </form>
    </div><!-- /.modal -->


    <!--修改科目 显示模态框（Modal） -->
    <div class="modal fade in" id="myModaledit" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
        <div class="modal-backdrop fade in" id="gbttt" style="height:100%;"></div>
        <form class="form-horizontal" name="question_sub_runedit" id="question_sub_runedit" method="post"
              action="/index.php/Admin/Qust/question_sub_runedit">
            <input type="hidden" name="question_sub_id" id="edit_question_sub_id" value=""/>
            <div class="modal-dialog" style="width:70%;">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" id="gbtt" aria-hidden="true">×
                        </button>
                        <h4 class="modal-title" id="myModalLabel">
                            修改考试科目</h4>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-xs-12">

                                <div class="form-group">
                                    <label class="col-sm-2 control-label no-padding-right" for="form-field-1">
                                        科目名称： </label>
                                    <div class="col-sm-10">
                                        <input type="text" name="question_sub_title" id="edit_question_sub_title"
                                               placeholder="输入单位名称" class="col-xs-10 col-sm-8"/>
                                    </div>
                                </div>
                                <div class="space-4"></div>
                            </div>
                        </div>


                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">
                            提交保存
                        </button>
                        <button type="button" class="btn btn-default" id="gbt" data-dismiss="modal">
                            关闭
                        </button>
                    </div>
                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </form>
    </div><!-- /.modal -->


    <!-- 试卷设置 -->
    <div class="modal fade in" id="myModaleditset" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
        <div class="modal-backdrop fade in" id="gbtxxx" style="height:100%;"></div>
        <form class="form-horizontal" name="question_set_runedit" id="question_set_runedit" method="post"
              action="/index.php/Admin/Qust/question_set_runedit">
            <input type="hidden" name="question_details_id" id="question_details_id" value=""/>
            <div class="modal-dialog" style="width:70%;">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" id="gbtxx" aria-hidden="true">×
                        </button>
                        <h4 class="modal-title" id="myModalLabel">
                            试卷设置</h4>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-xs-12">

                                <div class="form-group">
                                    <label class="col-sm-2 control-label no-padding-right" for="form-field-1">
                                        考试时长： </label>
                                    <div class="col-sm-10">
                                        <input type="text" name="question_details_time" id="question_details_time"
                                               placeholder="输入考试总时间" class="col-xs-10 col-sm-2"/><span class="lbl">&nbsp;&nbsp;分钟</span>

                                    </div>
                                </div>
                                <div class="space-4"></div>
                                <link rel="stylesheet" type="text/css" media="all"
                                      href="/Public/sldate/daterangepicker-bs3.css"/>
                                <script type="text/javascript" src="/Public/sldate/moment.js"></script>
                                <script type="text/javascript" src="/Public/sldate/daterangepicker.js"></script>
                                <script type="text/javascript">
                                    $(document).ready(function () {
                                        $('#reservation').daterangepicker(null, function (start, end, label) {
                                            console.log(start.toISOString(), end.toISOString(), label);
                                        });
                                    });
                                </script>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label no-padding-right" for="form-field-1">
                                        考试日期范围： </label>
                                    <div class="col-sm-10">
                                        <input type="text" name="reservation" id="reservation" class="sl-date"
                                               value="<?php echo ($sldate); ?>" placeholder="点击选择日期范围"/><span class="lbl">&nbsp;&nbsp;时间范围内可进行考试</span>
                                    </div>
                                </div>
                                <div class="space-4"></div>

                                <div class="form-group">
                                    <label class="col-sm-2 control-label no-padding-right" for="form-field-1">
                                        单选题数： </label>
                                    <div class="col-sm-10">
                                        <input type="text" name="question_details_dan" id="question_details_dan"
                                               placeholder="考题数目" class="col-xs-10 col-sm-1"/>
                                        <label class="col-sm-2 control-label no-padding-right" for="form-field-1">
                                            每题分值： </label>
                                        <input type="text" name="question_details_dannum" id="question_details_dannum"
                                               placeholder="题目分值" class="col-xs-10 col-sm-1"/>
                                    </div>
                                </div>
                                <div class="space-4"></div>

                                <div class="form-group">
                                    <label class="col-sm-2 control-label no-padding-right" for="form-field-1">
                                        多选题数： </label>
                                    <div class="col-sm-10">
                                        <input type="text" name="question_details_duo" id="question_details_duo"
                                               placeholder="考题数目" class="col-xs-10 col-sm-1"/>
                                        <label class="col-sm-2 control-label no-padding-right" for="form-field-1">
                                            每题分值： </label>
                                        <input type="text" name="question_details_duonum" id="question_details_duonum"
                                               placeholder="题目分值" class="col-xs-10 col-sm-1"/>
                                    </div>
                                </div>
                                <div class="space-4"></div>

                                <div class="form-group">
                                    <label class="col-sm-2 control-label no-padding-right" for="form-field-1">
                                        判断题数： </label>
                                    <div class="col-sm-10">
                                        <input type="text" name="question_details_pan" id="question_details_pan"
                                               placeholder="考题数目" class="col-xs-10 col-sm-1"/>
                                        <label class="col-sm-2 control-label no-padding-right" for="form-field-1">
                                            每题分值： </label>
                                        <input type="text" name="question_details_pannum" id="question_details_pannum"
                                               placeholder="题目分值" class="col-xs-10 col-sm-1"/>
                                    </div>
                                </div>
                                <div class="space-4"></div>

                                <div class="form-group">
                                    <label class="col-sm-2 control-label no-padding-right" for="form-field-1">
                                        填空题数： </label>
                                    <div class="col-sm-10">
                                        <input type="text" name="question_details_tian" id="question_details_tian"
                                               placeholder="考题数目" class="col-xs-10 col-sm-1"/>
                                        <label class="col-sm-2 control-label no-padding-right" for="form-field-1">
                                            每题分值： </label>
                                        <input type="text" name="question_details_tiannum" id="question_details_tiannum"
                                               placeholder="题目分值" class="col-xs-10 col-sm-1"/>
                                    </div>
                                </div>
                                <div class="space-4"></div>

                                <div class="form-group">
                                    <label class="col-sm-2 control-label no-padding-right" for="form-field-1">
                                        问答题数： </label>
                                    <div class="col-sm-10">
                                        <input type="text" name="question_details_wen" id="question_details_wen"
                                               placeholder="考题数目" class="col-xs-10 col-sm-1"/>
                                        <label class="col-sm-2 control-label no-padding-right" for="form-field-1">
                                            每题分值： </label>
                                        <input type="text" name="question_details_wennum" id="question_details_wennum"
                                               placeholder="题目分值" class="col-xs-10 col-sm-1"/>
                                    </div>
                                </div>
                                <div class="space-4"></div>

                                <div class="form-group">
                                    <label class="col-sm-2 control-label no-padding-right" for="form-field-1">
                                        考卷总分值： </label>
                                    <div class="col-sm-10">
                                        <input type="text" name="question_details_countnum"
                                               id="question_details_countnum" class="col-xs-10 col-sm-1"/>
                                    </div>
                                </div>
                                <div class="space-4"></div>


                            </div>
                        </div>


                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">
                            提交保存
                        </button>
                        <button type="button" class="btn btn-default" id="gbtx" data-dismiss="modal">
                            关闭
                        </button>
                    </div>
                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </form>
    </div><!-- /.modal -->


    <script>

        function del(id, p) {
            layer.confirm('你确定要删除吗？', {icon: 3}, function (index) {
                layer.close(index);
                window.location.href = "/index.php/Admin/Qust/question_sub_del/question_sub_id/" + id + "/p/" + p + "";
            });
        }


        function question_sub_edit(id, title) {
            $(document).ready(function () {
                $("#myModaledit").show(300);
                $("#edit_question_sub_id").val(id);
                $("#edit_question_sub_title").val(title);
            });
        }


        //修改模态框状态
        $(document).ready(function () {
            $("#gbt").click(function () {
                $("#myModaledit").hide(200);
            });
            $("#gbtt").click(function () {
                $("#myModaledit").hide(200);
            });
            $("#gbttt").click(function () {
                $("#myModaledit").hide(200);
            });

            $("#gbtx").click(function () {
                $("#myModaleditset").hide(200);
            });
            $("#gbtxx").click(function () {
                $("#myModaleditset").hide(200);
            });
            $("#gbtxxx").click(function () {
                $("#myModaleditset").hide(200);
            });
        });


        $(function () {
            $('#question_sub_runadd').ajaxForm({
                beforeSubmit: checkForm, // 此方法主要是提交前执行的方法，根据需要设置
                success: complete, // 这是提交后的方法
                dataType: 'json'
            });

            function checkForm() {
                if ('' == $.trim($('#question_sub_title').val())) {
                    layer.alert('考试科目名称不能为空', {icon: 6}, function (index) {
                        layer.close(index);
                        $('#question_sub_title').focus();
                    });
                    return false;
                }
            }

            function complete(data) {
                if (data.status == 1) {
                    layer.alert(data.info, {icon: 6}, function (index) {
                        layer.close(index);
                        window.location.href = data.url;
                    });
                    return false;
                } else {
                    layer.alert(data.info, {icon: 6}, function (index) {
                        layer.close(index);
                        window.location.href = data.url;
                    });
                    return false;
                }
            }
        });

        $(function () {
            $('#question_sub_runedit').ajaxForm({
                beforeSubmit: checkForm, // 此方法主要是提交前执行的方法，根据需要设置
                success: complete, // 这是提交后的方法
                dataType: 'json'
            });

            function checkForm() {
                if ('' == $.trim($('#edit_question_sub_title').val())) {
                    layer.alert('考试科目名称不能为空', {icon: 6}, function (index) {
                        layer.close(index);
                        $('#edit_question_sub_title').focus();
                    });
                    return false;
                }
            }

            function complete(data) {
                if (data.status == 1) {
                    layer.alert(data.info, {icon: 6}, function (index) {
                        layer.close(index);
                        window.location.href = data.url;
                    });
                    return false;
                } else {
                    layer.alert(data.info, {icon: 6}, function (index) {
                        layer.close(index);
                        window.location.href = data.url;
                    });
                    return false;
                }
            }
        });


        //设置试卷
        function question_sub_set(val) {
            $.post('<?php echo U("question_sub_set");?>', {question_sub_id: val}, function (data) {
                console.log(data);
                if (data.status == 1) {
                    $(document).ready(function () {
                        var reservation = data.question_details_starttime + ' - ' + data.question_details_endtime;
                        $("#myModaleditset").show(300);
                        $("#question_details_id").val(data.question_details_id);
                        $("#question_details_time").val(data.question_details_time);
                        $("#reservation").val(reservation);
                        $("#question_details_dan").val(data.question_details_dan);
                        $("#question_details_dannum").val(data.question_details_dannum);

                        $("#question_details_duo").val(data.question_details_duo);
                        $("#question_details_duonum").val(data.question_details_duonum);

                        $("#question_details_pan").val(data.question_details_pan);
                        $("#question_details_pannum").val(data.question_details_pannum);

                        $("#question_details_tian").val(data.question_details_tian);
                        $("#question_details_tiannum").val(data.question_details_tiannum);

                        $("#question_details_wen").val(data.question_details_wen);
                        $("#question_details_wennum").val(data.question_details_wennum);

                        $("#question_details_countnum").val(data.question_details_countnum);
                    });
                } else {
                    layer.alert('参数错误', {icon: 6}, function (index) {
                        layer.close(index);
                        window.location.href = data.url;
                    });
                    return false;
                }
            });
            return false;
        }

        //试卷分数不能超过100
        $(document).ready(function () {
            $("#question_details_tian,#question_details_tiannum,#question_details_dan,#question_details_dannum,#question_details_duo,#question_details_duonum,#question_details_pan,#question_details_pannum").keyup(function () {
                $("#question_details_countnum").val(parseFloat($("#question_details_tian").val() * $("#question_details_tiannum").val()) +parseFloat($("#question_details_dan").val() * $("#question_details_dannum").val()) + parseFloat($("#question_details_duo").val() * $("#question_details_duonum").val()) + parseFloat($("#question_details_pan").val() * $("#question_details_pannum").val()));

                if ($("#question_details_countnum").val() > 100) {
                    layer.alert('试卷总分值超出100分，请重新输入', {icon: 6}, function (index) {
                        layer.close(index);
                        window.location.href = data.url;
                    });
                    return false;
                }
            });

        });


        $(function () {
            $('#question_set_runedit').ajaxForm({
                beforeSubmit: checkForm, // 此方法主要是提交前执行的方法，根据需要设置
                success: complete, // 这是提交后的方法
                dataType: 'json'
            });

            function checkForm() {
                if ('' == $("#question_details_time").val()) {
                    layer.alert('考试时长不能为空', {icon: 6}, function (index) {
                        layer.close(index);
                        $('#question_details_time').focus();
                    });
                    return false;
                }

                if ('' == $.trim($('#reservation').val())) {
                    layer.alert('考题日期范围不能为空', {icon: 6}, function (index) {
                        layer.close(index);
                        $('#reservation').focus();
                    });
                    return false;
                }
            }

            function complete(data) {
                if (data.status == 1) {
                    layer.alert(data.info, {icon: 6}, function (index) {
                        layer.close(index);
                        window.location.href = data.url;
                    });
                    return false;
                } else {
                    layer.alert(data.info, {icon: 6}, function (index) {
                        layer.close(index);
                        window.location.href = data.url;
                    });
                    return false;
                }
            }
        });


    </script>
    			<div class="footer">
				<div class="footer-inner">
					<!-- #section:basics/footer -->
					<div class="footer-content">
						<span class="bigger-120">
							<span class="blue bolder"></span>
							风河信息科技有限公司网络在线考试与管理系统 &copy; 2016-2017
						</span>
					</div>

					<!-- /section:basics/footer -->
				</div>
			</div>
            

		<!-- basic scripts -->


<!--[if IE]>
<script type="text/javascript">
 window.jQuery || document.write("<script src='../assets/js/jquery1x.js'>"+"<"+"/script>");
</script>
<![endif]-->

		<script src="/Public/assets/js/bootstrap.js"></script>
		<script src="/Public/assets/js/maxlength.js"></script>
		<script src="/Public/assets/js/ace/ace.js"></script>
		<script src="/Public/assets/js/ace/ace.sidebar.js"></script>


		<!-- inline scripts related to this page -->
		<script type="text/javascript">
			jQuery(function($) {
			   $('#sidebar2').insertBefore('.page-content');
			   
			   $('.navbar-toggle[data-target="#sidebar2"]').insertAfter('#menu-toggler');
			   
			   
			   $(document).on('settings.ace.two_menu', function(e, event_name, event_val) {
				 if(event_name == 'sidebar_fixed') {
					 if( $('#sidebar').hasClass('sidebar-fixed') ) {
						$('#sidebar2').addClass('sidebar-fixed');
						$('#navbar').addClass('h-navbar');
					 }
					 else {
						$('#sidebar2').removeClass('sidebar-fixed')
						$('#navbar').removeClass('h-navbar');
					 }
				 }
			   }).triggerHandler('settings.ace.two_menu', ['sidebar_fixed' ,$('#sidebar').hasClass('sidebar-fixed')]);
			})
		</script>


</div><!-- /.main-container -->
</body>
</html>