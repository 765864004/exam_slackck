<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>响应式手机网站模板，手机网站模板，WebApp，模板微网站模板 - 科蚁网</title>
    <meta name="viewport" content="width=device-width,initial-scale=1"/>
    <meta name="keywords" content="微信网站模板,微网站模板,手机网站模板,微官网模板,WebApp模板,响应式手机模板,响应式网站模板,手机网站大全"/>
    <meta name="description" content="科蚁网提供大量的手机网站模板,微网站模板,WebApp网站模板下载和学习"/>
    <link rel="stylesheet" type="text/css" href="/Public/assets/mobile/style/reset.css"/>
    <link rel="stylesheet" type="text/css" href="/Public/assets/mobile/style/root.css"/>
    <script type="text/javascript" src="/Public/assets/mobile/js/jquery.min.js"></script>
    <script type="text/javascript" src="/Public/assets/mobile/js/toogle.js"></script>

    <script src="/Public/assets/js/jquery.min.js"></script>
    <script src="/Public/assets/js/jquery.form.js"></script>
    <script src="/Public/layer/layer.js"></script>

    <style>
        #header .logo{margin: 8px 0 0 0;}
    </style>
</head>
<body>

<!-- start header -->
<div id="header">
    <a href="#"><img src="/Public/assets/mobile/img/logo2.png" width="120" height="32" alt="logo" class="logo"/></a>
    <a href="javascript:history.go(-1);" class="button back"><img src="/Public/assets/mobile/img/back-button.png" width="15" height="16" alt="icon"/></a>
    <a href="<?php echo U('Index/index');?>" class="button create"><img src="/Public/assets/mobile/img/home.png" width="16" height="16" alt="icon"/></a>
    <div class="clear"></div>
</div>
<!-- end header -->

<!-- start searchbox -->
<div class="searchbox">
    <form id="form1" name="form1" method="post" action="">
        <input type="text" name="textfield" id="textfield" class="txtbox"/>
    </form>
</div>
<!-- end searchbox -->
<style>
    .center {
        text-align: center;
    }

    .list-arrow li {
        background: none;
    }

    .list-arrow li {
        padding: 5px 0 0 5px;
    }
    .reset-button{ margin: 0 0 0 22px;}
    .answer{display: none;}
</style>

<!-- start page -->
<div class="page">


    <!-- start error page -->
    <div class="simplebox">
        <h1 class="titleh">开始考试</h1>
        <div class="content">

            <h5 class="center"><?php echo ($sub_list["question_sub_title"]); ?></h5>
            <p class="center" style="margin: 0 0 10px 0;">考试时间共<?php echo ($sub_list["question_details_time"]); ?>分钟</p>

            <form class="form-horizontal" name="exam_runadd" id="exam_runadd" method="post"
                  action="/index.php/Mobile/Exam/exam_runadd">
                <input type="hidden" name="question_sub_id" value="<?php echo ($sub_list["question_sub_id"]); ?>"/>

                <b>一、单选题(共：<?php echo ($sub_list["question_details_dan"]); ?>题，每题<?php echo ($sub_list["question_details_dannum"]); ?>分)</b>

                <?php if(is_array($list_list_1)): $i = 0; $__LIST__ = $list_list_1;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><blockquote>
                        <b><?php echo ($i); ?>、<?php echo ($v["question_list_var"]); ?></b>
                        <div class="albox succesbox answer">这里是成功的提示信息.</div>
                        <ul class="list-arrow" data-id="<?php echo ($v["question_list_subid"]); ?>" data-list="<?php echo ($v["question_list_id"]); ?>">
                            <li><input type="radio" value="a" data="dan<?php echo ($i); ?>[]" name="dan_op<?php echo ($v["question_list_id"]); ?>"/>A、<?php echo ($v["question_list_op1"]); ?></li>
                            <li><input type="radio" value="b" data="dan<?php echo ($i); ?>[]" name="dan_op<?php echo ($v["question_list_id"]); ?>"/>B、<?php echo ($v["question_list_op2"]); ?></li>
                            <li><input type="radio" value="c" data="dan<?php echo ($i); ?>[]" name="dan_op<?php echo ($v["question_list_id"]); ?>"/>C、<?php echo ($v["question_list_op3"]); ?></li>
                            <?php if(!empty($v["question_list_op4"])){?>
                            <li><input type="radio" value="d" data="dan{$i}[]" name="dan_op<?php echo ($v["question_list_id"]); ?>"/>D、<?php echo ($v["question_list_op4"]); ?></li>
                            <?php } ?>
                        </ul>
                        <input type="button" value="提交并查看正确答案" class="reset-button button_dan" name="dan_op<?php echo ($v["question_list_id"]); ?>">
                    </blockquote><?php endforeach; endif; else: echo "" ;endif; ?>

                <b>二、多选题(共：<?php echo ($sub_list["question_details_duo"]); ?>题，每题<?php echo ($sub_list["question_details_duonum"]); ?>分)</b>

                <?php if(is_array($list_list_2)): $i = 0; $__LIST__ = $list_list_2;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><blockquote>
                        <b><?php echo ($i); ?>、<?php echo ($v["question_list_var"]); ?></b>
                        <div class="albox succesbox answer">这里是成功的提示信息.</div>
                        <ul class="list-arrow"  data-id="<?php echo ($v["question_list_subid"]); ?>" data-list="<?php echo ($v["question_list_id"]); ?>">
                            <li><input type="checkbox" value="a" name="duo_op<?php echo ($v["question_list_id"]); ?>[]"/>A、<?php echo ($v["question_list_op1"]); ?>
                            </li>
                            <li><input type="checkbox" value="b" name="duo_op<?php echo ($v["question_list_id"]); ?>[]"/>B、<?php echo ($v["question_list_op2"]); ?>
                            </li>
                            <li><input type="checkbox" value="c" name="duo_op<?php echo ($v["question_list_id"]); ?>[]"/>C、<?php echo ($v["question_list_op3"]); ?>
                            </li>
                            <li><input type="checkbox" value="d" name="duo_op<?php echo ($v["question_list_id"]); ?>[]"/>D、<?php echo ($v["question_list_op4"]); ?>
                            </li>
                        </ul>
                        <input type="button" value="提交并查看正确答案" class="reset-button button_duo" name="duo_op<?php echo ($v["question_list_id"]); ?>">
                    </blockquote><?php endforeach; endif; else: echo "" ;endif; ?>
                <br>


                <b>三、判断题(共：<?php echo ($sub_list["question_details_pan"]); ?>题，每题<?php echo ($sub_list["question_details_pannum"]); ?>分)</b>

                <?php if(is_array($list_list_3)): $i = 0; $__LIST__ = $list_list_3;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><blockquote>
                        <b><?php echo ($i); ?>、<?php echo ($v["question_list_var"]); ?></b>
                        <div class="albox succesbox answer">这里是成功的提示信息.</div>
                        <ul class="list-arrow" data-id="<?php echo ($v["question_list_subid"]); ?>" data-list="<?php echo ($v["question_list_id"]); ?>">
                            <li><input type="radio" value="1" name="pan_op<?php echo ($v["question_list_id"]); ?>"/>A、正确</li>
                            <li><input type="radio" value="0" name="pan_op<?php echo ($v["question_list_id"]); ?>"/>B、错误</li>
                        </ul>
                        <input type="button" value="提交并查看正确答案" class="reset-button button_pan" name="pan_op<?php echo ($v["question_list_id"]); ?>">
                    </blockquote><?php endforeach; endif; else: echo "" ;endif; ?>

                <b>四、填空题(共：<?php echo ($sub_list["question_details_tian"]); ?>题，每题<?php echo ($sub_list["question_details_tiannum"]); ?>分) </b>

                <?php if(is_array($list_list_4)): $i = 0; $__LIST__ = $list_list_4;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><blockquote>
                        <b><?php echo ($i); ?>、<?php echo ($v["question_list_var"]); ?></b>
                        <div class="albox succesbox answer">这里是成功的提示信息.</div>
                        <ul class="list-arrow" data-id="<?php echo ($v["question_list_subid"]); ?>" data-list="<?php echo ($v["question_list_id"]); ?>">
                            <?php if(is_array($v["ans"])): $k = 0; $__LIST__ = $v["ans"];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$an): $mod = ($k % 2 );++$k;?><li>
                                    <label class="col-sm-12 left_30">第<?php echo ($k); ?>个空：
                                        <input type="text" name="tian_op<?php echo ($v["question_list_id"]); ?>[]"/>
                                    </label>
                                </li><?php endforeach; endif; else: echo "" ;endif; ?>
                        </ul>
                        <input type="button" value="提交并查看正确答案" class="reset-button button_tian" name="tian_op<?php echo ($v["question_list_id"]); ?>">
                    </blockquote><?php endforeach; endif; else: echo "" ;endif; ?>


                <b>五、问答题(共：<?php echo ($sub_list["question_details_wen"]); ?>题，每题<?php echo ($sub_list["question_details_wennum"]); ?>分) </b>

                <?php if(is_array($list_list_5)): $i = 0; $__LIST__ = $list_list_5;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><blockquote>
                        <b><?php echo ($i); ?>、<?php echo ($v["question_list_var"]); ?></b>
                        <div class="albox succesbox answer">这里是成功的提示信息.</div>
                        <ul class="list-arrow" data-id="<?php echo ($v["question_list_subid"]); ?>" data-list="<?php echo ($v["question_list_id"]); ?>">
                            <li>
                                <label class="col-sm-12 left_30">答案：
                                    <textarea class="textarea" style="width: 90%; height: 100px;" name="wen_op<?php echo ($v["question_list_id"]); ?>"></textarea>
                                </label>
                            </li>
                        </ul>
                        <input type="button" value="提交并查看正确答案" class="reset-button button_wen" name="wen_op<?php echo ($v["question_list_id"]); ?>">
                    </blockquote><?php endforeach; endif; else: echo "" ;endif; ?>

                <div class="form-line" style="text-align: center;">
                    <input type="submit" name="button" id="button" value="&nbsp;提交试卷&nbsp;" class="submit-button"/>
                </div>

            </form>
        </div>
    </div>

    <!-- end error page -->

    <script>
        $(function(){
            function htmlDecode(value){
                return $('<div/>').html(value).text();
            }

            //单选
            $(".button_dan").click(function(){
                var listid = $(this).siblings(".list-arrow").data("list") //试题id

                //答案
                var list_name = $(this).attr("name"); //button 当前试题序号
                var answer= $('input[name="'+list_name+'"]:checked').val();
                var _this = $(this);
                $.getJSON("/index.php/Mobile/Exam/answer.html",{question_list_id:listid, answer:answer}, function(data){
                    console.log(data);
                    if(data.answer2 == "1"){
                        _this.siblings(".answer").fadeIn(600).addClass("succesbox").removeClass("errorbox").text(data.answer+"/正确答案为："+data.question_list_ans);
                    }else{
                        _this.siblings(".answer").fadeIn(600).addClass("errorbox").removeClass("succesbox").text(data.answer+"/正确答案为："+data.question_list_ans);
                    }
                })
            })

            //多选
            $(".button_duo").click(function(){
                var listid = $(this).siblings(".list-arrow").data("list") //试题id

                //答案
                var list_name = $(this).attr("name"); //button 当前试题序号
                list_name=list_name+'[]';
                var chk_value =[];
                $('input[name="'+list_name+'"]:checked').each(function(){
                    chk_value.push($(this).val());
                });

                var _this = $(this);
                $.getJSON("/index.php/Mobile/Exam/answer.html",{question_list_id:listid, answer:chk_value}, function(data){
                    console.log(data);
                    if(data.answer2 == "1"){
                        _this.siblings(".answer").fadeIn(600).addClass("succesbox").removeClass("errorbox").text(data.answer+"/正确答案为："+data.question_list_ans);
                    }else{
                        _this.siblings(".answer").fadeIn(600).addClass("errorbox").removeClass("succesbox").text(data.answer+"/正确答案为："+data.question_list_ans);
                    }
                })
            })

            //判断题
            $(".button_pan").click(function(){
                var listid = $(this).siblings(".list-arrow").data("list") //试题id

                //答案
                var list_name = $(this).attr("name"); //button 当前试题序号
                var answer= $('input[name="'+list_name+'"]:checked').val();

                var _this = $(this);
                $.getJSON("/index.php/Mobile/Exam/answer.html",{question_list_id:listid, answer:answer}, function(data){
                    console.log(data);
                    var res = "";
                    var ans = data.question_list_ans;
                    if(ans == 1){
                        res = "正确";
                    }else{
                        res = "错误";
                    }
                    if(data.answer2 == "1"){
                        _this.siblings(".answer").fadeIn(600).addClass("succesbox").removeClass("errorbox").text(data.answer+"/正确答案为："+res);
                    }else{
                        _this.siblings(".answer").fadeIn(600).addClass("errorbox").removeClass("succesbox").text(data.answer+"/正确答案为："+res);
                    }
                })
            })


            //填空
            $(".button_tian").click(function(){
                var listid = $(this).siblings(".list-arrow").data("list") //试题id

                //答案
                var list_name = $(this).attr("name"); //button 当前试题序号
                list_name=list_name+'[]';
                var chk_value =[];
                $('input[name="'+list_name+'"]').each(function(){
                    if(''!= $(this).val()){
                        chk_value.push($(this).val());
                    }
                });

                var _this = $(this);
                $.getJSON("/index.php/Mobile/Exam/answer.html",{question_list_id:listid, answer:chk_value}, function(data){
                    console.log(data);
                    if(data.answer2 == "1"){
                        _this.siblings(".answer").fadeIn(600).addClass("succesbox").removeClass("errorbox").text(data.answer+"/正确答案为："+data.question_list_ans);
                    }else{
                        _this.siblings(".answer").fadeIn(600).addClass("errorbox").removeClass("succesbox").text(data.answer+"/正确答案为："+data.question_list_ans);
                    }
                })
            })

            //问答
            $(".button_wen").click(function(){
                var listid = $(this).siblings(".list-arrow").data("list") //试题id

                var answer = $(this).siblings(".list-arrow").find(".textarea").val();

                var _this = $(this);
                $.getJSON("<?php echo U('Exam/answer');?>",{question_list_id:listid, answer:answer}, function(data){
                    console.log(data);
                    _this.siblings(".list-arrow").find(".textarea").val(htmlDecode(data.question_list_ans));
                    if(data.answer2 == "1"){
                        _this.siblings(".answer").fadeIn(600).addClass("succesbox").removeClass("errorbox").text(data.answer);
                    }else{
                        _this.siblings(".answer").fadeIn(600).addClass("errorbox").removeClass("succesbox").text(data.answer);
                    }
                })
            })

        })
    </script>
    <script type="text/javascript" src="/Public/assets/js/region.js"></script>
    <script>

        $(function(){
            $('#exam_runadd').ajaxForm({
                //beforeSubmit: checkForm, // 此方法主要是提交前执行的方法，根据需要设置
                success: complete, // 这是提交后的方法
                dataType: 'json'
            });

            function complete(data){
                console.log(data);
                if(data.status==1){
                    layer.alert(data.info, {icon: 6}, function(index){
                        layer.close(index);
                        window.location.href=data.url;
                    });
                }else{
                    layer.alert(data.info, {icon: 6}, function(index){
                        layer.close(index);
                        window.location.href=data.url;
                    });
                    return false;
                }
            }

        });
    </script>

    <!-- start top button -->
<div class="topbutton"><a href="#"><span>Top</span></a></div>
<!-- end top button -->


<!-- start footer -->
<div class="footer" style=" width:330px; text-align:center;margin: 0 auto;">
	© 2016 - 2017 风河信息科技 <a href="http://www.fonho.cn/">www.fonho.cn</a></div>
<!-- end footer -->


<div class="clear"></div>
</div>
<!-- end page -->
<script type="text/javascript" src="/Public/assets/mobile/js/frame.js"></script>
</body>
</html>