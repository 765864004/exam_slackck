<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>响应式手机网站模板，手机网站模板，WebApp，模板微网站模板 - 科蚁网</title>
    <meta name="viewport" content="width=device-width,initial-scale=1"/>
    <meta name="keywords" content="微信网站模板,微网站模板,手机网站模板,微官网模板,WebApp模板,响应式手机模板,响应式网站模板,手机网站大全"/>
    <meta name="description" content="科蚁网提供大量的手机网站模板,微网站模板,WebApp网站模板下载和学习"/>
    <link rel="stylesheet" type="text/css" href="/Public/assets/mobile/style/reset.css"/>
    <link rel="stylesheet" type="text/css" href="/Public/assets/mobile/style/root.css"/>
    <script type="text/javascript" src="/Public/assets/mobile/js/jquery.min.js"></script>
    <script type="text/javascript" src="/Public/assets/mobile/js/toogle.js"></script>

    <script src="/Public/assets/js/jquery.min.js"></script>
    <script src="/Public/assets/js/jquery.form.js"></script>
    <script src="/Public/layer/layer.js"></script>

    <style>
        #header .logo{margin: 8px 0 0 0;}
    </style>
</head>
<body>

<!-- start header -->
<div id="header">
    <a href="#"><img src="/Public/assets/mobile/img/logo2.png" width="120" height="32" alt="logo" class="logo"/></a>
    <a href="javascript:history.go(-1);" class="button back"><img src="/Public/assets/mobile/img/back-button.png" width="15" height="16" alt="icon"/></a>
    <a href="<?php echo U('Index/index');?>" class="button create"><img src="/Public/assets/mobile/img/home.png" width="16" height="16" alt="icon"/></a>
    <div class="clear"></div>
</div>
<!-- end header -->

<!-- start searchbox -->
<div class="searchbox">
    <form id="form1" name="form1" method="post" action="">
        <input type="text" name="textfield" id="textfield" class="txtbox"/>
    </form>
</div>
<!-- end searchbox -->

<style>
    .btn{ margin: 10px 0 0 0;}
    #button{ margin: 14px 0 14px 0; font-weight: normal; font-size: 13px;}
</style>
<!-- start page -->
<div class="page">


    <!-- start error page -->

    <div class="simplebox">
        <h1 class="titleh">查看错题</h1>
        <div class="content">
            <table class="tabledata">
                <thead>
                <tr>
                    <th width="20%">考试科目</th>
                    <th width="35%">题目</th>
                    <th width="10%">题型</th>
                    <th width="35%">答案</th>
                </tr>
                </thead>

                <tbody>
                <?php if(is_array($false_lists)): foreach($false_lists as $key=>$v): ?><tr>
                        <td><?php echo ($v["question_sub_title"]); ?></td>
                        <td><?php echo ($v["question_list_var"]); ?></td>
                        <td>
                            <?php if($v['question_list_type'] == 1){ ?>
                            <?php echo "单选";?>
                            <?php }elseif($v['question_list_type'] == 2){ ?>
                            <?php echo "多选";?>
                            <?php }elseif($v['question_list_type'] == 3){ ?>
                            <?php echo "判断";?>
                            <?php }elseif($v['question_list_type'] == 4){ ?>
                            <?php echo "填空";?>
                            <?php } ?>
                        </td>
                        <td>
                            <?php if($v["question_list_type"] != 3){ ?>
                            <?php echo ($v["question_list_ans"]); ?> </br>
                            <?php } ?>
                            <?php echo ($v["standard"]); ?>
                        </td>
                    </tr><?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- start top button -->
<div class="topbutton"><a href="#"><span>Top</span></a></div>
<!-- end top button -->


<!-- start footer -->
<div class="footer" style=" width:330px; text-align:center;margin: 0 auto;">
	© 2016 - 2017 风河信息科技 <a href="http://www.fonho.cn/">www.fonho.cn</a></div>
<!-- end footer -->


<div class="clear"></div>
</div>
<!-- end page -->
<script type="text/javascript" src="/Public/assets/mobile/js/frame.js"></script>
</body>
</html>