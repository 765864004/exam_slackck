<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>响应式手机网站模板，手机网站模板，WebApp，模板微网站模板 - 科蚁网</title>
    <meta name="viewport" content="width=device-width,initial-scale=1"/>
    <meta name="keywords" content="微信网站模板,微网站模板,手机网站模板,微官网模板,WebApp模板,响应式手机模板,响应式网站模板,手机网站大全"/>
    <meta name="description" content="科蚁网提供大量的手机网站模板,微网站模板,WebApp网站模板下载和学习"/>
    <link rel="stylesheet" type="text/css" href="/Public/assets/mobile/style/reset.css"/>
    <link rel="stylesheet" type="text/css" href="/Public/assets/mobile/style/root.css"/>
    <script type="text/javascript" src="/Public/assets/mobile/js/jquery.min.js"></script>
    <script type="text/javascript" src="/Public/assets/mobile/js/toogle.js"></script>

    <script src="/Public/assets/js/jquery.min.js"></script>
    <script src="/Public/assets/js/jquery.form.js"></script>
    <script src="/Public/layer/layer.js"></script>

    <style>
        #header .logo{margin: 8px 0 0 0;}
    </style>
</head>
<body>

<!-- start header -->
<div id="header">
    <a href="#"><img src="/Public/assets/mobile/img/logo2.png" width="120" height="32" alt="logo" class="logo"/></a>
    <a href="javascript:history.go(-1);" class="button back"><img src="/Public/assets/mobile/img/back-button.png" width="15" height="16" alt="icon"/></a>
    <a href="<?php echo U('Index/index');?>" class="button create"><img src="/Public/assets/mobile/img/home.png" width="16" height="16" alt="icon"/></a>
    <div class="clear"></div>
</div>
<!-- end header -->

<!-- start searchbox -->
<div class="searchbox">
    <form id="form1" name="form1" method="post" action="">
        <input type="text" name="textfield" id="textfield" class="txtbox"/>
    </form>
</div>
<!-- end searchbox -->
<script language="javascript" type="text/javascript" src="/Public/mobile/js/public.js"></script>
<script type="text/javascript" src="/Public/mobile/js/jquery.SuperSlide.js"></script>
<link href="/Public/mobile/css/style.css" rel="stylesheet">


<!-- start page -->
<div class="page">


    <!-- start profile box -->
    <div class="profilebox">
        <img src="/Public/assets/mobile/img/avatar.png" width="19" height="20" alt="avatar" class="avatar"/> 欢迎 <?php echo ($_SESSION['member_list_realname']); ?><b>　用户</b>
        <a href="#" class="logout">logout</a>
        <div class="clear"></div>
    </div>
    <!-- end profile box -->

    <!--效果html开始-->
    <div class="mBan2">
        <div id="slideBox" class="slideBox">
            <div class="hd">
                <ul ><li></li><li></li><li></li></ul>
            </div>
            <div class="bd">
                <ul>
                    <li><a href="#" target="_blank"><img src="/Public/mobile/images/1.jpg" /></a></li>
                    <li><a href="#" target="_blank"><img src="/Public/mobile/images/2.jpg" /></a></li>
                    <li><a href="#" target="_blank"><img src="/Public/mobile/images/3.jpg" /></a></li>
                </ul>
            </div>
        </div>
    </div>

    <!--效果html结束-->

    <!-- start menu -->
    <ul id="menu">
        <li>
            <a href="<?php echo U('Member/member_list_edit');?>">
                <img src="/Public/assets/mobile/img/icons/files.png" width="21" height="21"
                     alt="icon" class="m-icon"/><b>个人信息设置</b></a>
        </li>
        <li>
            <a href="<?php echo U('Exam/exam_list');?>">
                <img src="/Public/assets/mobile/img/icons/bubble.png" width="29" height="21"
                     alt="icon" class="m-icon"/><b>进入考场</b></a>
        </li>
        <li>
            <a href="<?php echo U('Exam/exam_score');?>">
                <img src="/Public/assets/mobile/img/icons/graph.png" width="24" height="21"
                     alt="icon" class="m-icon"/><b>成绩查询 <span>9</span> </b></a></li>
        <li>
            <a href="<?php echo U('Index/me');?>">
                <img src="/Public/assets/mobile/img/icons/blocks.png" width="25" height="21"
                     alt="icon" class="m-icon"/><b>关于我们<span class="red">15</span> </b></a></li>
    </ul>
    <!-- end menu -->


    <script language="javascript">
        jQuery(".slideBox").slide({mainCell:".bd ul",effect:"fold",autoPlay:true,trigger:"click"});
    </script>
    <script>
        $(function(){

            $(".flash").hover(function(){ //鼠标hover时左右按钮显示隐藏
                $(".arrow div").show();
            },function(){
                $(".arrow div").hide();
            });

            //默认的index 是 0，也就是第一页
            var index = 0;
////////////////////////////////////////////////////////////
            //定时器
            var run=function(){
                index++;
                if(index==6) {
                    index = 0;
                }
                $(".dot li").eq(index).addClass("hover").siblings().removeClass("hover");
                $('.flash .img div').eq(index).fadeIn(600).siblings().fadeOut(600);
            };

            var id=setInterval(run,1000); //运行定时器

            $(".flash").hover(function(){
                clearInterval(id);	//鼠标移入清楚定时器
            },function(){
                id=setInterval(run,600); //鼠标移开开启定时器
            });
/////////////////////////////////////////////////////////////

            $(".dot li").mouseenter(function(){ //.dot li鼠标移入事件 （序号）
                index = $(this).index();	//定义索引值
                $(this).addClass("hover").siblings().removeClass("hover");  //当前li添加class li的兄弟节点移除class
                $('.flash .img div').eq(index).fadeIn(600).siblings().fadeOut(600); //当鼠标移入时和li序号对应的img显示 img的兄弟节点隐藏
            });

            $(".arrow .right").click(function(){ //右箭头点击事件
                index++;
                if(index==6) {
                    index = 0;
                }
                $(".dot li").eq(index).addClass("hover").siblings().removeClass("hover");
                $('.flash .img div').eq(index).fadeIn(600).siblings().fadeOut(600);
            })

            $(".arrow .left").click(function(){ //左箭头点击事件
                index--;
                if(index==-1) {
                    index =$(".img div").length-1;
                }
                $(".dot li").eq(index).addClass("hover").siblings().removeClass("hover");
                $('.flash .img div').eq(index).fadeIn(600).siblings().fadeOut(600);
            })
        });
    </script>

    <!-- start top button -->
<div class="topbutton"><a href="#"><span>Top</span></a></div>
<!-- end top button -->


<!-- start footer -->
<div class="footer" style=" width:330px; text-align:center;margin: 0 auto;">
	© 2016 - 2017 风河信息科技 <a href="http://www.fonho.cn/">www.fonho.cn</a></div>
<!-- end footer -->


<div class="clear"></div>
</div>
<!-- end page -->
<script type="text/javascript" src="/Public/assets/mobile/js/frame.js"></script>
</body>
</html>