<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>响应式手机网站模板，手机网站模板，WebApp，模板微网站模板 - 科蚁网</title>
    <meta name="viewport" content="width=device-width,initial-scale=1"/>
    <meta name="keywords" content="微信网站模板,微网站模板,手机网站模板,微官网模板,WebApp模板,响应式手机模板,响应式网站模板,手机网站大全"/>
    <meta name="description" content="科蚁网提供大量的手机网站模板,微网站模板,WebApp网站模板下载和学习"/>
    <link rel="stylesheet" type="text/css" href="/Public/assets/mobile/style/reset.css"/>
    <link rel="stylesheet" type="text/css" href="/Public/assets/mobile/style/root.css"/>
    <script type="text/javascript" src="/Public/assets/mobile/js/jquery.min.js"></script>
    <script type="text/javascript" src="/Public/assets/mobile/js/toogle.js"></script>

    <script src="/Public/assets/js/jquery.min.js"></script>
    <script src="/Public/assets/js/jquery.form.js"></script>
    <script src="/Public/layer/layer.js"></script>

    <style>
        #header .logo{margin: 8px 0 0 0;}
    </style>
</head>
<body>

<!-- start header -->
<div id="header">
    <a href="#"><img src="/Public/assets/mobile/img/logo2.png" width="120" height="32" alt="logo" class="logo"/></a>
    <a href="javascript:history.go(-1);" class="button back"><img src="/Public/assets/mobile/img/back-button.png" width="15" height="16" alt="icon"/></a>
    <a href="<?php echo U('Index/index');?>" class="button create"><img src="/Public/assets/mobile/img/home.png" width="16" height="16" alt="icon"/></a>
    <div class="clear"></div>
</div>
<!-- end header -->

<!-- start searchbox -->
<div class="searchbox">
    <form id="form1" name="form1" method="post" action="">
        <input type="text" name="textfield" id="textfield" class="txtbox"/>
    </form>
</div>
<!-- end searchbox -->
<style>
    .st-label {
        float: left;
        height: 32px;
        line-height: 32px;
        font-size: 14px;
    }

    .mem_btn {
        text-align: center;
    }
</style>

<!-- start page -->
<div class="page">


    <!-- start error page -->

    <div class="simplebox">
        <h1 class="titleh">修改个人信息</h1>
        <div class="content">

            <form  name="member_list_edit" id="member_list_edit" method="post" action="/index.php/Mobile/Member/member_list_runedit">
                <input type="hidden" name="member_list_id" id="member_list_id" value="<?php echo ($member_list_edit["member_list_id"]); ?>" />
                <div class="form-line">
                    <label class="st-label">姓　　名：</label>
                    <input type="text" name="member_list_username" readonly id="member_list_username" style=" width:60%;"
                           value="<?php echo ($member_list_edit["member_list_username"]); ?>"/>
                </div>

                <div class="form-line">
                    <label class="st-label">密　　码：</label>
                    <input type="text" name="member_list_pwd" id="member_list_pwd" style=" width:60%;" placeholder="输入登录密码"/>
                </div>

                <div class="form-line">
                    <label class="st-label">真实姓名：</label>
                    <input type="text" name="member_list_realname" id="member_list_realname" style=" width:60%;"
                           value="<?php echo ($member_list_edit["member_list_realname"]); ?>"/>
                </div>

                <div class="form-line">
                    <label class="st-label">手机号码：</label>
                    <input type="text" name="member_list_tel" id="member_list_tel" style=" width:60%;"
                           value="<?php echo ($member_list_edit["member_list_tel"]); ?>"/>
                </div>

                <div class="form-line">
                    <label class="st-label">联系邮箱：</label>
                    <input type="text" name="member_list_email" id="member_list_email" style=" width:60%;"
                           value="<?php echo ($member_list_edit["member_list_email"]); ?>"/>
                </div>

                <div class="form-line mem_btn">
                    <input type="submit" name="button" id="button" value="&nbsp;提 交&nbsp;" class="submit-button"/>
                    <input type="submit" name="button" id="button2" value="&nbsp;重 置&nbsp;" class="reset-button"/>
                </div>
            </form>
        </div>
    </div>

    <script type="text/javascript" src="/Public/assets/js/region.js"></script>
    <script>

        $(function(){
            $('#member_list_edit').ajaxForm({
                beforeSubmit: checkForm, // 此方法主要是提交前执行的方法，根据需要设置
                success: complete, // 这是提交后的方法
                dataType: 'json'
            });

            function checkForm(){

                if( '' == $.trim($('#member_list_realname').val())){
                    layer.alert('真实姓名不能为空', {icon: 6}, function(index){
                        layer.close(index);
                        $('#member_list_realname').focus();
                    });
                    return false;
                }

                if (!$("#member_list_tel").val().match(/^(((13[0-9]{1})|(15[0-9]{1})|(17[0-9]{1})|(18[0-9]{1}))+\d{8})$/)) {
                    layer.alert('电话号码格式不正确', {icon: 6}, function(index){
                        layer.close(index);
                        $('#member_list_tel').focus();
                    });
                    return false;
                }

                if( '' == $.trim($('#member_list_email').val())){
                    layer.alert('邮箱不能为空', {icon: 6}, function(index){
                        layer.close(index);
                        $('#member_list_email').focus();
                    });
                    return false;
                }

            }
            function complete(data){
                if(data.status==1){
                    layer.alert(data.info, {icon: 6}, function(index){
                        layer.close(index);
                        window.location.href=data.url;
                    });
                }else{
                    layer.alert(data.info, {icon: 6}, function(index){
                        layer.close(index);
                        window.location.href=data.url;
                    });
                    return false;
                }
            }

        });
    </script>

    <!-- start top button -->
<div class="topbutton"><a href="#"><span>Top</span></a></div>
<!-- end top button -->


<!-- start footer -->
<div class="footer" style=" width:330px; text-align:center;margin: 0 auto;">
	© 2016 - 2017 风河信息科技 <a href="http://www.fonho.cn/">www.fonho.cn</a></div>
<!-- end footer -->


<div class="clear"></div>
</div>
<!-- end page -->
<script type="text/javascript" src="/Public/assets/mobile/js/frame.js"></script>
</body>
</html>