<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
	<head>
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
		<meta charset="utf-8" />
		<title>网络在线考试系统</title>

		<meta name="description" content="" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />

		<!-- bootstrap & fontawesome -->
		<link rel="stylesheet" href="/Public/assets/css/bootstrap.css" />
		<link rel="stylesheet" href="/Public/assets/css/font-awesome.css" />

		<!-- ace styles -->
		<link rel="stylesheet" href="/Public/assets/css/ace.css" class="ace-main-stylesheet" id="main-ace-style" />

		<!--[if lte IE 9]>
			<link rel="stylesheet" href="/Public/assets/css/ace-part2.css" class="ace-main-stylesheet" />
		<![endif]-->

		<!--[if lte IE 9]>
		  <link rel="stylesheet" href="/Public/assets/css/ace-ie.css" />
		<![endif]-->

		<!-- inline styles related to this page -->
        <link rel="stylesheet" href="/Public/assets/css/slackck.css" />
		<!-- ace settings handler -->
		<script src="/Public/assets/js/ace-extra.js"></script>
		<script src="/Public/assets/js/jquery.min.js"></script>
		<script src="/Public/assets/js/jquery.form.js"></script>
		<script src="/Public/layer/layer.js"></script>
		<!--<script src="/Public/assets/js/jquery.leanModal.min.js"></script>-->

		<!--[if lte IE 8]>
		<script src="/Public/assets/js/html5shiv.js"></script>
		<script src="/Public/assets/js/respond.js"></script>
		<![endif]-->
	</head>

	<body class="no-skin">
		<!-- #section:basics/navbar.layout -->
		<div id="navbar" class="navbar navbar-default    navbar-collapse">
			<div class="navbar-container" id="navbar-container">
				<!-- /section:basics/sidebar.mobile.toggle -->
				<div class="navbar-header pull-left">
					<!-- #section:basics/navbar.layout.brand -->
					<a href="<?php echo U('Index/index');?>" class="navbar-brand">
						<small>
							<i class="fa fa-leaf"></i>
							网络在线考试系统
						</small>
					</a>

				</div>

				<!-- #section:basics/navbar.dropdown -->
				<div class="navbar-buttons navbar-header pull-right  collapse navbar-collapse" role="navigation">
					<ul class="nav ace-nav">
					<li class="transparent"></li>
	
						<!-- #section:basics/navbar.user_menu -->
						<li class="light-blue">
							<a data-toggle="dropdown" href="#" class="dropdown-toggle">
								<img class="nav-user-photo" src="/Public/assets/avatars/user.jpg" alt="Jason's Photo" />
								<span class="user-info">
									<small>Welcome,</small>
									<?php echo ($_SESSION['member_list_realname']); ?>
								</span>

								<i class="ace-icon fa fa-caret-down"></i>
							</a>

							<ul class="user-menu dropdown-menu-right dropdown-menu dropdown-yellow dropdown-caret dropdown-close">
								<li>
									<a href="javascript:;"  id="logout">
										<i class="ace-icon fa fa-power-off"></i>
										注销
									</a>
								</li>
							</ul>
						</li>

						<!-- /section:basics/navbar.user_menu -->
					</ul>
				</div>

				<!-- /section:basics/navbar.dropdown -->
			</div><!-- /.navbar-container -->
		</div>


<script type="text/javascript">
$(document).ready(function(){
	$("#logout").click(function(){
		layer.confirm('你确定要退出吗？', {icon: 3}, function(index){
	    layer.close(index);
	    window.location.href="<?php echo U('Login/logout');?>";
	});
	});
});



$(function(){
$('#cache').click(function(){
if(confirm("确认要清除缓存？")){
var $type=$('#type').val();
var $mess=$('#mess');
$.post('/index.php/Home/Exam/clear',{type:$type},function(data){
alert("缓存清理成功");
});
}else{
return false;
}
});
});
</script>



<style>
    .lable{ float: left;}
    .answer{ display: none; width: 200px; height: 24px; line-height: 24px; color: #ffffff; float: left; padding: 0 5px 0 5px; text-align: center;}
    .col_true{ background: #00b7ee;}
    .col_false{ background:#d15b47;}
</style>

<!-- /section:basics/navbar.layout -->
<div class="main-container" id="main-container">

    <!-- #section:basics/sidebar -->

    <div id="sidebar" class="sidebar responsive">

    <div class="sidebar-shortcuts" id="sidebar-shortcuts">
        <div class="sidebar-shortcuts-large" id="sidebar-shortcuts-large">
            <button class="btn btn-success">
                <i class="ace-icon fa fa-signal"></i>
            </button>

            <button class="btn btn-info">
                <i class="ace-icon fa fa-pencil"></i>
            </button>

            <!-- #section:basics/sidebar.layout.shortcuts -->
            <button class="btn btn-warning">
                <i class="ace-icon fa fa-users"></i>
            </button>

            <button class="btn btn-danger">
                <i class="ace-icon fa fa-cogs"></i>
            </button>

            <!-- /section:basics/sidebar.layout.shortcuts -->
        </div>

        <div class="sidebar-shortcuts-mini" id="sidebar-shortcuts-mini">
            <span class="btn btn-success"></span>

            <span class="btn btn-info"></span>

            <span class="btn btn-warning"></span>

            <span class="btn btn-danger"></span>
        </div>
    </div><!-- /.sidebar-shortcuts -->

    <ul class="nav nav-list">
        <?php $m = M('auth_q_rule'); $field = 'id,name,title,css'; $data = $m->field($field)->where('pid=0 AND menustatus=1')->order('sort')->select(); ?>

        <?php if(is_array($data)): foreach($data as $key=>$v): ?><li class="<?php if( CONTROLLER_NAME == $v['name']): ?>active open<?php endif; ?>"><!--open代表打开状态-->
            <a href="#" class="dropdown-toggle">
                <i class="menu-icon fa <?php echo ($v["css"]); ?>"></i>
							<span class="menu-text">
								<?php echo ($v["title"]); ?>
							</span>

                <b class="arrow fa fa-angle-down"></b>
            </a>

            <b class="arrow"></b>

            <ul class="submenu">
                <?php $m = M('auth_q_rule'); $dataa = $m->where(array('pid'=>$v['id'],'menustatus'=>1))->select(); ?>
                <?php if(is_array($dataa)): foreach($dataa as $key=>$j): ?><li class="<?php if( ($_SESSION['se'] == $j['id'])): ?>active<?php endif; ?>">
                    <a href="<?php echo U($j['name'],array('se'=>$j['id']));?>">
                        <i class="menu-icon fa fa-caret-right"></i>
                        <?php echo ($j["title"]); ?>
                    </a>
                    <b class="arrow"></b>
                    </li><?php endforeach; endif; ?>
            </ul>
            </li><?php endforeach; endif; ?>

    </ul><!-- /.nav-list -->

    <!-- #section:basics/sidebar.layout.minimize -->
    <div class="sidebar-toggle sidebar-collapse" id="sidebar-collapse">
        <i class="ace-icon fa fa-angle-double-left" data-icon1="ace-icon fa fa-angle-double-left"
           data-icon2="ace-icon fa fa-angle-double-right"></i>
    </div>

    <!-- /section:basics/sidebar.layout.minimize -->
    <script type="text/javascript">
        try {
            ace.settings.check('sidebar', 'collapsed')
        } catch (e) {
        }
    </script>
</div>



    <!-- /section:basics/sidebar -->
    <div class="main-content">
        <div class="main-content-inner">
            <div class="page-content">

                <!--主题-->
                <div class="page-header" style="text-align:center;">
                    <h1 style="text-align:center;">
                        <?php echo ($sub_list["question_sub_title"]); ?>
                    </h1><br/>

                    <span style="text-align:center;">考试时间共<?php echo ($sub_list["question_details_time"]); ?>分钟</span>
                </div>
                <div class="row">
                    <div class="col-xs-12">
                        <form class="form-horizontal" name="exam_runadd" id="exam_runadd" method="post"
                              action="/index.php/Home/Exam/exam_runadd_tea">
                            <input type="hidden" name="question_sub_id" value="<?php echo ($sub_list["question_sub_id"]); ?>"/>

                            <div class="form-group">
                                <label class="col-sm-12" for="form-field-1" style="font-weight:bold;">
                                    一、单选题(共：<?php echo ($sub_list["question_details_dan"]); ?>题，每题<?php echo ($sub_list["question_details_dannum"]); ?>分) </label>
                            </div>
                            <div class="space-4"></div>

                            <?php if(is_array($list_list_1)): $i = 0; $__LIST__ = $list_list_1;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><div class="form-group"  data-id="<?php echo ($v["question_list_subid"]); ?>" data-list="<?php echo ($v["question_list_id"]); ?>">
                                    <label class="col-sm-12 title">
                                        <div class="lable"><?php echo ($i); ?>、<?php echo ($v["question_list_var"]); ?></div>
                                        <div class="answer">查看正确答案</div>
                                    </label>

                                    <label class="col-sm-12 left_30">
                                        <input type="radio" value="a" data="dan<?php echo ($i); ?>[]" name="dan_op<?php echo ($v["question_list_id"]); ?>"/>A、<?php echo ($v["question_list_op1"]); ?>
                                    </label>
                                    <label class="col-sm-12 left_30">
                                        <input type="radio" value="b" data="dan<?php echo ($i); ?>[]" name="dan_op<?php echo ($v["question_list_id"]); ?>"/>B、<?php echo ($v["question_list_op2"]); ?></label>
                                    <label class="col-sm-12 left_30">
                                        <input type="radio" value="c" data="dan<?php echo ($i); ?>[]" name="dan_op<?php echo ($v["question_list_id"]); ?>"/>C、<?php echo ($v["question_list_op3"]); ?></label>
                                    <?php if(!empty($v["question_list_op4"])){?>
                                    <label class="col-sm-12 left_30">
                                        <input type="radio" value="d" data="dan{$i}[]" name="dan_op<?php echo ($v["question_list_id"]); ?>"/>D、<?php echo ($v["question_list_op4"]); ?></label>
                                    <?php }?>
                                    <input type="button" class="button_dan" name="dan_op<?php echo ($v["question_list_id"]); ?>" value="提交并查看答案" style="margin: 0px 0 0 30px;">
                                </div>
                                <div class="space-4"></div><?php endforeach; endif; else: echo "" ;endif; ?>


                            <!--多选题 S-->
                            <div class="form-group">
                                <label class="col-sm-12" for="form-field-1" style="font-weight:bold;">
                                    二、多选题(共：<?php echo ($sub_list["question_details_duo"]); ?>题，每题<?php echo ($sub_list["question_details_duonum"]); ?>分)
                                </label>
                            </div>
                            <div class="space-4"></div>
                            <?php if(is_array($list_list_2)): $i = 0; $__LIST__ = $list_list_2;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><div class="form-group" data-id="<?php echo ($v["question_list_subid"]); ?>" data-list="<?php echo ($v["question_list_id"]); ?>">
                                    <label class="col-sm-12 title">
                                        <div class="lable"><?php echo ($i); ?>、<?php echo ($v["question_list_var"]); ?></div>
                                        <div class="answer">查看正确答案</div>
                                    </label>
                                    <label class="col-sm-12 left_30">
                                        <input type="checkbox" value="a" data="duo<?php echo ($i); ?>[]" name="duo_op<?php echo ($v["question_list_id"]); ?>[]"/>A、<?php echo ($v["question_list_op1"]); ?>
                                    </label>
                                    <label class="col-sm-12 left_30">
                                        <input type="checkbox" value="b" data="duo<?php echo ($i); ?>[]" name="duo_op<?php echo ($v["question_list_id"]); ?>[]"/>B、<?php echo ($v["question_list_op2"]); ?>
                                    </label>
                                    <label class="col-sm-12 left_30">
                                        <input type="checkbox" value="c" data="duo<?php echo ($i); ?>[]" name="duo_op<?php echo ($v["question_list_id"]); ?>[]"/>C、<?php echo ($v["question_list_op3"]); ?>
                                    </label>
                                    <label class="col-sm-12 left_30">
                                        <input type="checkbox" value="d" data="duo<?php echo ($i); ?>[]" name="duo_op<?php echo ($v["question_list_id"]); ?>[]"/>D、<?php echo ($v["question_list_op4"]); ?>
                                    </label>
                                    <input type="button" class="button" name="duo_op<?php echo ($v["question_list_id"]); ?>" value="提交并查看答案" style="margin: 0px 0 0 30px;">
                                </div>
                                <div class="space-4"></div><?php endforeach; endif; else: echo "" ;endif; ?>
                            <!--多选题 E-->

                            <!--判断题 S-->
                            <div class="form-group">
                                <label class="col-sm-12" for="form-field-1" style="font-weight:bold;">
                                    三、判断题(共：<?php echo ($sub_list["question_details_pan"]); ?>题，每题<?php echo ($sub_list["question_details_pannum"]); ?>分) </label>
                            </div>
                            <div class="space-4"></div>

                            <?php if(is_array($list_list_3)): $i = 0; $__LIST__ = $list_list_3;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><div class="form-group" data-id="<?php echo ($v["question_list_subid"]); ?>" data-list="<?php echo ($v["question_list_id"]); ?>">
                                    <label class="col-sm-12 title">
                                        <div class="lable"><?php echo ($i); ?>、<?php echo ($v["question_list_var"]); ?></div>
                                        <div class="answer">查看正确答案</div>
                                    </label>
                                    <label class="col-sm-12 left_30">
                                        <input type="radio" value="1" name="pan_op<?php echo ($v["question_list_id"]); ?>"/>A、正确</label>
                                    <label class="col-sm-12 left_30">
                                        <input type="radio" value="0" name="pan_op<?php echo ($v["question_list_id"]); ?>"/>B、错误</label>
                                    <input type="button" class="button_pan" name="pan_op<?php echo ($v["question_list_id"]); ?>" value="提交并查看答案" style="margin: 0px 0 0 30px;">
                                </div>
                                <div class="space-4"></div><?php endforeach; endif; else: echo "" ;endif; ?>
                            <!--判断题 E-->

                            <div class="form-group">
                                <label class="col-sm-12" for="form-field-1" style="font-weight:bold;">
                                    四、填空题(共：<?php echo ($sub_list["question_details_tian"]); ?>题，每题<?php echo ($sub_list["question_details_tiannum"]); ?>分) </label>
                            </div>
                            <div class="space-4"></div>

                            <?php if(is_array($list_list_4)): $i = 0; $__LIST__ = $list_list_4;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><div class="form-group" data-id="<?php echo ($v["question_list_subid"]); ?>" data-list="<?php echo ($v["question_list_id"]); ?>">
                                    <label class="col-sm-12 title">
                                        <div class="lable"><?php echo ($i); ?>、<?php echo ($v["question_list_var"]); ?></div>
                                        <div class="answer" style="width: auto;">查看正确答案</div>
                                    </label>

                                    <?php if(is_array($v["ans"])): $k = 0; $__LIST__ = $v["ans"];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$an): $mod = ($k % 2 );++$k;?><label class="col-sm-12 left_30">第<?php echo ($k); ?>个空：
                                            <input type="text" name="tian_op<?php echo ($v["question_list_id"]); ?>[]"/></label><?php endforeach; endif; else: echo "" ;endif; ?>

                                    <input type="button" class="button_tian" name="tian_op<?php echo ($v["question_list_id"]); ?>" value="提交并查看答案" style="margin: 0px 0 0 30px;">
                                </div>
                                <div class="space-4"></div><?php endforeach; endif; else: echo "" ;endif; ?>


                            <div class="form-group">
                                <label class="col-sm-12" for="form-field-1" style="font-weight:bold;">
                                    五、问答题(共：<?php echo ($sub_list["question_details_wen"]); ?>题，每题<?php echo ($sub_list["question_details_wennum"]); ?>分) </label>
                            </div>
                            <div class="space-4"></div>

                            <?php if(is_array($list_list_5)): $i = 0; $__LIST__ = $list_list_5;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><div class="form-group" data-id="<?php echo ($v["question_list_subid"]); ?>" data-list="<?php echo ($v["question_list_id"]); ?>">
                                    <label class="col-sm-12 title">
                                        <div class="lable"><?php echo ($i); ?>、<?php echo ($v["question_list_var"]); ?></div>
                                        <div class="answer" style="width: auto;">查看正确答案</div>
                                    </label>

                                    <label class="col-sm-12 left_30">答案：<br/>
                                        <textarea class="textarea" style="width: 60%; height: 120px;" name="wen_op<?php echo ($v["question_list_id"]); ?>"></textarea>
                                    </label>
                                    <input type="button" class="button_wen" name="wen_op<?php echo ($v["question_list_id"]); ?>" value="提交并查看答案" style="margin: 0px 0 0 30px;">

                                </div>
                                <div class="space-4"></div><?php endforeach; endif; else: echo "" ;endif; ?>


                            <div class="clearfix form-actions">
                                <div class="col-md-offset-5">
                                    <button class="btn btn-info" type="submit">
                                        <i class="ace-icon fa fa-check bigger-110"></i>
                                        提交试卷
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="hr hr-24"></div>

                <div class="breadcrumbs breadcrumbs-fixed" id="breadcrumbs">
	<div class="row">
		<div class="col-xs-12">
			<div class="">
				<div id="sidebar2" class="sidebar h-sidebar navbar-collapse collapse collapse_btn">
					<ul class="nav nav-list header-nav" id="header-nav">
                                        
    <?php $m = M('auth_q_rule'); $dataaa = $m->where(array('pid'=>$_SESSION['se'],'menustatus'=>1))->order('sort')->select(); ?>
    <?php if(is_array($dataaa)): foreach($dataaa as $key=>$k): ?><li>
												<a href="<?php echo U(''.$k['name'].'');?>">
													<o class="font12 <?php if((CONTROLLER_NAME.'/'.ACTION_NAME == $k['name'])): ?>rigbg<?php endif; ?>"><?php echo ($k["title"]); ?></o>
												</a>

								<b class="arrow"></b>
							</li><?php endforeach; endif; ?>
					</ul><!-- /.nav-list -->
				</div><!-- .sidebar -->
			</div>
		</div><!-- /.col -->
	</div><!-- /.row -->
	
</div>

            </div><!-- /.page-content -->
        </div>
    </div><!-- /.main-content -->

    			<div class="footer">
				<div class="footer-inner">
					<!-- #section:basics/footer -->
					<div class="footer-content">
						<span class="bigger-120">
							<span class="blue bolder"></span>
							风河信息科技有限公司网络在线考试与管理系统 &copy; 2016-2017
						</span>
					</div>

					<!-- /section:basics/footer -->
				</div>
			</div>
            

		<!-- basic scripts -->


<!--[if IE]>
<script type="text/javascript">
 window.jQuery || document.write("<script src='../assets/js/jquery1x.js'>"+"<"+"/script>");
</script>
<![endif]-->

		<script src="/Public/assets/js/bootstrap.js"></script>
		<script src="/Public/assets/js/maxlength.js"></script>
		<script src="/Public/assets/js/ace/ace.js"></script>
		<script src="/Public/assets/js/ace/ace.sidebar.js"></script>


		<!-- inline scripts related to this page -->
		<script type="text/javascript">
			jQuery(function($) {
			   $('#sidebar2').insertBefore('.page-content');
			   
			   $('.navbar-toggle[data-target="#sidebar2"]').insertAfter('#menu-toggler');
			   
			   
			   $(document).on('settings.ace.two_menu', function(e, event_name, event_val) {
				 if(event_name == 'sidebar_fixed') {
					 if( $('#sidebar').hasClass('sidebar-fixed') ) {
						$('#sidebar2').addClass('sidebar-fixed');
						$('#navbar').addClass('h-navbar');
					 }
					 else {
						$('#sidebar2').removeClass('sidebar-fixed')
						$('#navbar').removeClass('h-navbar');
					 }
				 }
			   }).triggerHandler('settings.ace.two_menu', ['sidebar_fixed' ,$('#sidebar').hasClass('sidebar-fixed')]);
			})
		</script>


</div><!-- /.main-container -->

<script>
    $(function(){

//        $(".button").click(function(){
//            var adIds = "";
//            $("input:checkbox:checked").each(function(){
//                adIds+=$(this).val()+",";
//            });
//            alert(adIds);
//        })

        function htmlDecode(value){
            return $('<div/>').html(value).text();
        }

        //问答
        $(".button_wen").click(function(){
            var subid = $(this).parents(".form-group").data("id") //科目id
            var listid = $(this).parents(".form-group").data("list") //试题id

            var answer = $(this).parents(".form-group").find(".textarea").val();

            var _this = $(this);
            $.getJSON("<?php echo U('Exam/answer');?>",{question_list_id:listid, answer:answer}, function(data){
                //alert(data);
                console.log(data);
                //ht = $.parseHTML( data.question_list_ans ),
                _this.parents(".form-group").find(".textarea").val(htmlDecode(data.question_list_ans));
                //_this.siblings(".title").children(".answer").fadeIn(600).text(data.answer);
                if(data.answer2 == "1"){
                    _this.siblings(".title").children(".answer").fadeIn(600).addClass("col_true").removeClass("col_false").text(data.answer);
                }else{
                    _this.siblings(".title").children(".answer").fadeIn(600).addClass("col_false").removeClass("col_true").text(data.answer);
                }
            })
        })


        //填空
        $(".button_tian").click(function(){
            var subid = $(this).parents(".form-group").data("id") //科目id
            var listid = $(this).parents(".form-group").data("list") //试题id

            //答案
            var list_name = $(this).attr("name"); //button 当前试题序号
            list_name=list_name+'[]';
            var chk_value =[];
            $('input[name="'+list_name+'"]').each(function(){
                if(''!= $(this).val()){
                    chk_value.push($(this).val());
                }
            });
            //alert(chk_value);

            var _this = $(this);
            $.getJSON("/index.php/Home/Exam/answer.html",{question_list_subid:subid, question_list_id:listid, answer:chk_value}, function(data){
                //alert(data);
                console.log(data);
                if(data.answer2 == "1"){
                    _this.siblings(".title").children(".answer").fadeIn(600).addClass("col_true").removeClass("col_false").text(data.answer+"/正确答案为："+data.question_list_ans);
                }else{
                    _this.siblings(".title").children(".answer").fadeIn(600).addClass("col_false").removeClass("col_true").text(data.answer+"/正确答案为："+data.question_list_ans);
                }
            })
        })



        //判断题
        $(".button_pan").click(function(){
            var subid = $(this).parents(".form-group").data("id") //科目id
            var listid = $(this).parents(".form-group").data("list") //试题id

            //答案
            var list_name = $(this).attr("name"); //button 当前试题序号
            var answer= $('input[name="'+list_name+'"]:checked').val();

            var _this = $(this);
            $.getJSON("/index.php/Home/Exam/answer.html",{question_list_subid:subid, question_list_id:listid, answer:answer}, function(data){
                //alert(data);
                console.log(data);
                var res = "";
                var ans = data.question_list_ans;
                if(ans == 1){
                    res = "正确";
                }else{
                    res = "错误";
                }
                //_this.siblings(".title").children(".answer").fadeIn(600).text(data.answer+"/正确答案为："+res);
                if(data.answer2 == "1"){
                    _this.siblings(".title").children(".answer").fadeIn(600).addClass("col_true").removeClass("col_false").text(data.answer+"/正确答案为："+res);
                }else{
                    _this.siblings(".title").children(".answer").fadeIn(600).addClass("col_false").removeClass("col_true").text(data.answer+"/正确答案为："+res);
                }
            })
        })

        //单选
        $(".button_dan").click(function(){
            var subid = $(this).parents(".form-group").data("id") //科目id
            var listid = $(this).parents(".form-group").data("list") //试题id

            //答案
            var list_name = $(this).attr("name"); //button 当前试题序号
            var answer= $('input[name="'+list_name+'"]:checked').val();
            var _this = $(this);
            $.getJSON("/index.php/Home/Exam/answer.html",{question_list_subid:subid, question_list_id:listid, answer:answer}, function(data){
                //alert(data);
                console.log(data);
                if(data.answer2 == "1"){
                    _this.siblings(".title").children(".answer").fadeIn(600).addClass("col_true").removeClass("col_false").text(data.answer+"/正确答案为："+data.question_list_ans);
                }else{
                    _this.siblings(".title").children(".answer").fadeIn(600).addClass("col_false").removeClass("col_true").text(data.answer+"/正确答案为："+data.question_list_ans);
                }
            })
        })

        //多选
        $(".button").click(function(){
            var subid = $(this).parents(".form-group").data("id") //科目id
            var listid = $(this).parents(".form-group").data("list") //试题id

            //答案
            var list_name = $(this).attr("name"); //button 当前试题序号
            list_name=list_name+'[]';
            var chk_value =[];
            $('input[name="'+list_name+'"]:checked').each(function(){
               chk_value.push($(this).val());
            });
            //alert(chk_value);

            var _this = $(this);
            $.getJSON("/index.php/Home/Exam/answer.html",{question_list_subid:subid, question_list_id:listid, answer:chk_value}, function(data){
                //alert(data);
                console.log(data);
                if(data.answer2 == "1"){
                    _this.siblings(".title").children(".answer").fadeIn(600).addClass("col_true").removeClass("col_false").text(data.answer+"/正确答案为："+data.question_list_ans);
                }else{
                    _this.siblings(".title").children(".answer").fadeIn(600).addClass("col_false").removeClass("col_true").text(data.answer+"/正确答案为："+data.question_list_ans);
                }
            })
        })

    })
</script>
<script type="text/javascript" src="/Public/assets/js/region.js"></script>
<script>

    $(function(){
        $('#exam_runadd').ajaxForm({
            //beforeSubmit: checkForm, // 此方法主要是提交前执行的方法，根据需要设置
            success: complete, // 这是提交后的方法
            dataType: 'json'
        });

        function complete(data){
            console.log(data);
            if(data.status==1){
                layer.alert(data.info, {icon: 6}, function(index){
                    layer.close(index);
                    window.location.href=data.url;
                });
            }else{
                layer.alert(data.info, {icon: 6}, function(index){
                    layer.close(index);
                    window.location.href=data.url;
                });
                return false;
            }
        }

    });
</script>
</body>
</html>